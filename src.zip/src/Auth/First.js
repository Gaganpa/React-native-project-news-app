import React from 'react';
import {
    View, Text,
    TextInput,
    StyleSheet,
    TouchableOpacity,
    Image,
    LayoutAnimation,

} from 'react-native';
import { fontSize } from '../Utility/Fontsize';
import { horizScale, vertScale } from '../Utility/Layout';
import { Customimage } from '../Utility/Customimage';
import { Customcolor } from '../Utility/Customcolor';
function First({ navigation }) {
    return (
        <View style={styles.container}>
            <View>
                <Image style={styles.imagefirst}
                    source={Customimage.flash}>
                </Image>
            </View>
            <View>
                <Text style={styles.newtext}>NEWS APP</Text>
                <Text style={styles.subtitle}>
                    Never miss out on a breaking news!
                    We promise to keep you updated by delivering news in real-time
                </Text>
            </View>

            <TouchableOpacity onPress={() =>
                navigation.navigate('login')
            } style={styles.button1}>
                <Text style={{ color: Customcolor.white, }}>
                    Log In
                </Text>
            </TouchableOpacity>


            <TouchableOpacity onPress={() =>
                navigation.navigate('signup')
            } style={styles.button2} >
                <Text style={{ color: Customcolor.blue, }}>
                    Sign Up
                </Text>

            </TouchableOpacity>
        </View>
    )
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: Customcolor.white,
    },
    imagefirst: {
        width: horizScale(230),
        height: vertScale(200),
    },
    newtext: {
        fontSize: fontSize.h4,
        color: 'blue',
        alignSelf: 'center',
        fontWeight: 'bold',
        marginTop: vertScale(20),
    },
    subtitle: {
        fontSize: fontSize.reqular,
        justifyContent: 'center',
        textAlign: 'center',
        marginTop: vertScale(20),
        color: Customcolor.darkwhite,
    },
    button1: {
        padding: horizScale(13),
        backgroundColor: Customcolor.blue,
        width: horizScale(300),
        borderRadius: 30,
        elevation: 10,
        marginTop: vertScale(40),
        alignItems: 'center',
        justifyContent: 'center'
    },
    button2: {
        padding: horizScale(13),
        backgroundColor: Customcolor.white,
        width: horizScale(300),
        borderRadius: 30,
        elevation: 10,
        marginTop: vertScale(40),
        alignItems: 'center',
        justifyContent: 'center',
        borderWidth: 1,
        borderColor: Customcolor.blue,
    },
})
export default First;