import React from "react";
import {
    View, Text,
    StyleSheet,
    TouchableOpacity,
    Image,
    TextInput,
} from 'react-native';
import { Customcolor } from "../Utility/Customcolor";
import { fontSize } from "../Utility/Fontsize";
import { horizScale, vertScale } from "../Utility/Layout";
import { Customimage } from "../Utility/Customimage";

export default function OtpScreen({ navigation }) {
    return (
        <View style={styles.container}>
            <TouchableOpacity onPress={() => {
                navigation.goBack()
            }}>
                <Image style={{
                    width: horizScale(20), height: vertScale(20), marginTop: vertScale(10),
                    marginLeft: horizScale(10)
                }}
                    source={Customimage.back}></Image>
            </TouchableOpacity>
            <View>
                <Text style={{
                    fontSize: fontSize.h4,
                    color: Customcolor.blue,
                    fontWeight: '600',
                    marginLeft: horizScale(30),
                    marginTop: vertScale(30)

                }}>Sign In</Text>
            </View>
            <View style={{ marginTop: vertScale(20) }}>
                <TextInput placeholder="send code"
                    placeholderTextColor={'grey'}
                    style={{ marginLeft: horizScale(30) }}
                ></TextInput>
            </View>
            <TouchableOpacity onPress={() => {
                alert('coming soon')
            }}>
                <View style={styles.button1}>
                    <Text style={{
                        fontSize: fontSize.reqular,
                        color: Customcolor.white
                    }}>
                        Mobile Number</Text>
                </View>
            </TouchableOpacity>
            <View>
                <Text style={{
                    fontSize: fontSize.reqular,
                    color: Customcolor.black,
                    fontWeight: '600',
                    alignSelf: "center",
                    marginTop: vertScale(20),
                }}>OR</Text>
            </View>
            <TouchableOpacity onPress={() => {
                alert('coming soon')
            }}>
                <View style={styles.button2}>
                    <Text style={{ fontSize: fontSize.reqular, color: Customcolor.white }}>Login with facebook</Text>
                </View>
            </TouchableOpacity>
        </View >
    )
}
const styles = StyleSheet.create({
    container: {
        false: 1,
        backgroundColor: Customcolor.lightwhite,
    },
    button1: {
        backgroundColor: Customcolor.blue,
        width: horizScale(300),
        padding: horizScale(13),
        justifyContent: "center",
        alignItems: "center",
        alignSelf: "center",
        borderRadius: 30,
        marginTop: vertScale(20)
    },
    button2: {
        backgroundColor: Customcolor.lightblue,
        width: horizScale(300),
        padding: horizScale(13),
        justifyContent: "center",
        alignItems: "center",
        alignSelf: "center",
        borderRadius: 30,
        marginTop: vertScale(20)
    },

})