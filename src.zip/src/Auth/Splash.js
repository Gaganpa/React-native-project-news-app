import React, { useState, useEffect } from 'react';
import { Text, View, Image, StyleSheet } from 'react-native';
import { Customcolor } from '../Utility/Customcolor';
import { Customimage } from '../Utility/Customimage';
import { fontSize } from '../Utility/Fontsize';
import { horizScale, vertScale } from '../Utility/Layout';
function Splash({ navigation }) {
    const [align, setAlign] = useState();
    const [alignsecond, setAlignsecond] = useState(false);
    useEffect(() => {
        setTimeout(() => {
            navigation.navigate('auth')
        }, 3000);
    }, []);
    return (
        <View style={Styles.container}>
            <View>
                <Text style={{ fontSize: fontSize.h4, color: Customcolor.blue, alignSelf: 'center', fontWeight: 'bold', }}>
                    FLASHBYTES
                </Text>
                <Text style={{ fontSize: fontSize.h4, color: Customcolor.black, alignSelf: 'center', paddingTop: vertScale(20), }}>
                    Explore trending News,app
                </Text>
            </View>
            <View>
                <Image style={Styles.imageflash} source={Customimage.flash} />
            </View>
        </View>
    );
}
const Styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: Customcolor.white,
    },
    imageflash: {
        width: vertScale(300),
        height: horizScale(330),
        top: horizScale(20),
    }
})
export default Splash;