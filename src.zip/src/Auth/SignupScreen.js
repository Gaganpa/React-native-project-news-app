import { NavigationContainer } from '@react-navigation/native';
import React, { useState } from 'react';
import {
    View, TextInput, Text,
    ScrollView,
    StyleSheet,
    Image,
    TouchableOpacity,
} from "react-native";
import { SafeAreaView } from 'react-native-safe-area-context';
import { Customcolor } from '../Utility/Customcolor';
import { Customimage } from '../Utility/Customimage';
import { fontSize } from '../Utility/Fontsize';
import { horizScale, vertScale } from '../Utility/Layout';
function SignupScreen({ navigation }) {
    const [name, setName] = useState();
    const [mobile, setMobile] = useState();
    const [email, setEmail] = useState();
    const [newpassword, setNewPassword] = useState();
    const [ConfirmPassword, setConfirmPassword] = useState();
    return (
        <SafeAreaView style={styles.container}>
            <ScrollView>
                <View>
                    <TouchableOpacity onPress={() => {
                        navigation.goBack()
                    }}>
                        <Image style={{
                            width: horizScale(20), height: vertScale(20), marginTop: vertScale(10), marginLeft: horizScale(10)
                        }}
                            source={Customimage.back}></Image>
                    </TouchableOpacity>
                </View>
                <View>
                    <Text style={styles.textcna}>Create New Accound</Text>
                </View>

                <View>
                    <TouchableOpacity onPress={() => {
                        alert('coming soon')
                    }}>
                        <Image style={{
                            width: horizScale(90),
                            height: vertScale(90),
                            marginVertical: vertScale(30),
                            alignSelf: 'center'
                        }}
                            source={Customimage.photo}></Image>
                    </TouchableOpacity>
                </View>

                <View>
                    <TextInput onChangeText={(value) => {
                        setName(value)
                    }}
                        placeholder='Enter Name'
                        placeholderTextColor={'grey'}
                        style={styles.input}
                    >
                    </TextInput>
                    <TextInput onChangeText={(value) => {
                        setMobile(value)
                    }}
                        placeholder='Enter Mobile Number'
                        placeholderTextColor={'grey'}
                        style={styles.input}
                    >
                    </TextInput>
                    <TextInput onChangeText={(value) => {
                        setEmail(value)
                    }}
                        placeholder='Enter E-mail'
                        placeholderTextColor={'grey'}
                        style={styles.input}
                    >
                    </TextInput>
                    <TextInput onChangeText={(value) => {
                        setNewPassword(value)
                    }}
                        placeholder='Enter New Password'
                        placeholderTextColor={'grey'}
                        style={styles.input}
                    >
                    </TextInput>
                    <TextInput onChangeText={(value) => {
                        setConfirmPassword(value)
                    }}
                        placeholder='Enter confirem password'
                        placeholderTextColor={'grey'}
                        style={styles.input}
                    >
                    </TextInput>
                </View>
                <View >
                    <TouchableOpacity onPress={() =>
                        navigation.navigate('login')
                    } style={styles.button1} >
                        <Text style={{ color: Customcolor.white, fontSize: fontSize.reqular, }}>
                            Sign Up
                        </Text>

                    </TouchableOpacity>
                </View>
                <View>
                    <Text style={{
                        fontSize: fontSize.h5, justifyContent: 'center',
                        alignSelf: 'center', marginTop: vertScale(20),
                        color: Customcolor.black, fontWeight: '600'
                    }}>
                        OR
                    </Text>
                </View>
                <View>
                    <TouchableOpacity onPress={() =>
                        navigation.navigate('otp')
                    }>
                        <Text style={{
                            fontSize: fontSize.h6, justifyContent: 'center',
                            alignSelf: 'center', color: 'blue', marginTop: vertScale(20)
                        }}>
                            Sign up with phone Number
                        </Text>
                    </TouchableOpacity>
                </View>
            </ScrollView>
        </SafeAreaView>
    )
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Customcolor.lightwhite,
    },
    input: {
        width: 300,
        height: vertScale(40),
        color: Customcolor.darkwhite,
        borderRadius: 10,
        marginTop: vertScale(15),
        fontSize: fontSize.medium,
        paddingLeft: horizScale(12),
        alignSelf: 'center',
        backgroundColor: Customcolor.white,

    },
    textcna: {
        fontSize: fontSize.h4,
        marginLeft: horizScale(30),
        marginTop: vertScale(20),
        color: Customcolor.blue,
        fontWeight: 'bold'
    },
    imagephoto: {
        width: horizScale(100),
        height: vertScale(100),
        justifyContent: 'center',
        alignSelf: 'center',
        marginTop: vertScale(10),
    },
    button1: {
        padding: horizScale(12),
        backgroundColor: Customcolor.blue,
        width: horizScale(330),
        alignItems: 'center',
        borderRadius: 40,
        elevation: 10,
        justifyContent: 'center',
        marginTop: horizScale(40),
        alignSelf: 'center',

    },
})
export default SignupScreen;