import React from 'react';
import {
    View, Text,
    TextInput,
    StyleSheet,
    TouchableOpacity,
    Image,
} from 'react-native';
import { Customcolor } from '../Utility/Customcolor';
import { Customimage } from '../Utility/Customimage';
import { fontSize } from '../Utility/Fontsize';
import { horizScale, vertScale } from '../Utility/Layout';
function LoginScreen({ navigation }) {
    return (
        <View style={StyleSheet.container}>
            <View>
                <TouchableOpacity onPress={() => {
                    navigation.goBack()
                }}>
                    <Image style={{ width: horizScale(20), height: vertScale(20), marginTop: vertScale(10), marginLeft: horizScale(10) }}
                        source={Customimage.back}></Image>
                </TouchableOpacity>
            </View>
            <View>
                <Text style={{
                    color: Customcolor.blue,
                    fontSize: fontSize.h4,
                    fontWeight: '700',
                    marginLeft: horizScale(40),
                    marginTop: vertScale(20),
                }}>
                    Sign In</Text>
            </View>
            <View>
                <TextInput style={styles.inputLP}
                    placeholder='E-mail'
                    placeholderTextColor={'grey'}
                >
                </TextInput>
                <TextInput style={styles.inputLP}
                    placeholder='Passworld'
                    placeholderTextColor={'grey'}
                >
                </TextInput>
            </View>
            <View>
                <TouchableOpacity onPress={() =>
                    navigation.navigate('resetpass')
                }>
                    <Text style={styles.passwordtext}>Forgot Password?</Text>
                </TouchableOpacity>
            </View>

            <TouchableOpacity onPress={() =>
                navigation.navigate('homedrawer')
            } style={styles.button1}>

                <Text style={{
                    color: Customcolor.white,
                    fontWeight: '700',
                    fontSize: fontSize.reqular,
                }}>
                    Log In
                </Text>

            </TouchableOpacity>

            <View>
                <Text style={{
                    fontSize: fontSize.h6, alignSelf: 'center',
                    marginTop: vertScale(10), color: '#000000', fontWeight: '600',
                }}>
                    OR</Text>
            </View>
            <TouchableOpacity onPress={() => {
                alert('coming soon')
            }
            } >
                <View style={{ ...styles.button1, backgroundColor: Customcolor.lightblue }}>

                    <Text style={{ color: Customcolor.white, fontSize: fontSize.reqular, }}>
                        Login with google
                    </Text>
                </View>

            </TouchableOpacity>

            <TouchableOpacity onPress={() => {
                alert('coming soon')
            }
            } >
                <View style={{ ...styles.button1, backgroundColor: '#ff5c2c' }}>

                    <Text style={{ color: Customcolor.white, fontSize: fontSize.reqular, }}>
                        Login with facebook
                    </Text>
                </View>

            </TouchableOpacity>
        </View>
    )
}
const styles = StyleSheet.create({
    container: {
        flax: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: Customcolor.white,
    },
    inputLP: {
        width: horizScale(320),
        marginLeft: horizScale(35),
        borderRadius: 10,
        borderColor: 'grey',
        backgroundColor: Customcolor.white,
        elevation: 10,
        marginTop: vertScale(20),
        fontSize: fontSize.reqular,
        paddingLeft: horizScale(20),
        color: Customcolor.black,
    },
    passwordtext: {
        fontSize: fontSize.input,
        marginTop: vertScale(30),
        marginLeft: horizScale(200),
        color: Customcolor.lightblue,
        fontWeight: '600',
    },
    button1: {
        padding: horizScale(13),
        backgroundColor: Customcolor.blue,
        width: horizScale(300),
        alignSelf: 'center',
        borderRadius: 30,
        elevation: 10,
        justifyContent: 'center',
        alignItems: 'center',
        marginVertical: 20,

    },

})
export default LoginScreen;