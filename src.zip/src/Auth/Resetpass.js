import React from 'react';
import {
    View, Text,
    TextInput,
    StyleSheet,
    TouchableOpacity,
    Image,
} from 'react-native';
import { Customcolor } from '../Utility/Customcolor';
import { fontSize } from '../Utility/Fontsize';
import { horizScale, vertScale } from '../Utility/Layout';
import { Customimage } from '../Utility/Customimage';
function Resetpass({ navigation }) {
    return (
        <View style={styles.contaier}>
            <View>
                <TouchableOpacity onPress={() => {
                    navigation.goBack()
                }}>
                    <Image style={{ width: horizScale(20), height: vertScale(20), marginTop: vertScale(10), marginLeft: horizScale(10) }}
                        source={Customimage.back}></Image>
                </TouchableOpacity>
            </View>
            <View>
                <Text style={{
                    fontSize: fontSize.h4,
                    marginTop: vertScale(50),
                    color: Customcolor.blue,
                    fontWeight: 'bold',
                    marginLeft: horizScale(30)
                }}>
                    Reset Password</Text>
            </View>
            <View>
                <TextInput style={styles.input}
                    placeholder='E-mail'
                    placeholderTextColor={'grey'}
                >
                </TextInput>
            </View>
            <View style={styles.button1}>
                <TouchableOpacity onPress={() => {
                    alert('coming soon')
                }}>
                    <Text style={{ fontSize: fontSize.input, justifyContent: 'center', alignSelf: 'center', color: '#ffffff' }}>
                        Send Link
                    </Text>
                </TouchableOpacity>
            </View>
        </View>
    )
}
const styles = StyleSheet.create({
    contaier: {
        flex: 1,
        backgroundColor: Customcolor.white,
    },
    input: {
        width: horizScale(350),
        height: vertScale(50),
        elevation: 20,
        borderRadius: 10,
        backgroundColor: Customcolor.white,
        marginTop: vertScale(30),
        marginLeft: horizScale(30),
        fontSize: fontSize.reqular,
        paddingLeft: horizScale(20),
        color: Customcolor.black,
    },
    button1: {
        padding: vertScale(10),
        backgroundColor: Customcolor.blue,
        width: horizScale(330),
        alignSelf: 'center',
        borderRadius: 30,
        elevation: 10,
        justifyContent: 'center',
        marginTop: vertScale(30),

    },
})
export default Resetpass;