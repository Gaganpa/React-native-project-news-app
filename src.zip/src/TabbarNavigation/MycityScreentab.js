import React, { useState } from 'react';
import {
    View, Text, FlatList,
    StyleSheet,
    ScrollView,
    SafeAreaView,
    Image,
    ImageBackground,
    TouchableOpacity,
    Button,
} from 'react-native';
import { Customcolor } from '../Utility/Customcolor';
import { Customimage } from '../Utility/Customimage';
import { fontSize } from '../Utility/Fontsize';
import { horizScale, Layout, vertScale } from '../Utility/Layout';


const MycityScreentab = ({ navigation }) => {
    const [selectednews, setselectednews] = useState();

    const [news, setnews] = useState([
        {
            id: '1',
            name: 'टॉप',
            url: 'https://newsreach-publishers.s3.ap-south-1.amazonaws.com/asliazadi.com/2022/05/Samuh-Lagan-.jpeg',
            heading: 'धरमपुर के हथनबारी गांव में 25 आदिवासी जोडों के समूह लग्न में उपस्थित रहे संघ प्रदेश थ्रीडी भाजपा ओबीसी मोर्चा अध्यक्ष हरीश पटेल',
            discription: 'असली आजादी न्यूज नेटवर्क, धरमपुर 23 मई। गुजरात के धरमपुर तालुका के आंतरिक क्षेत्र में स्थित आदिवासी बहुल गांव हथनबारी में आज श्री कृष्ण परिवार और विश्व विख्यात कथाकार मेहुल जानी द्वारा 25 आदिवासी जोडों के लिए समूह लग्न का आयोजन किया गया था। गरीब आदिवासी परिवार की 25 बेटियां और 25 बेटे कथाकार मेहुल जानी का आशीर्वाद लेकर शादी के अटूट बंधन में बंध गये।',
            category: 'टॉप',

        },
        {
            id: '2',
            name: 'टॉप',
            url: 'https://newsreach-publishers.s3.ap-south-1.amazonaws.com/asliazadi.com/2022/05/Amit-Shah-Book-1.jpg',
            heading: 'पीएम मोदी की प्रामाणिकता और पारदर्शिता पर विरोधी भी नहीं उठा सकते उंगली : शाह',
            discription: 'नई दिल्ली (ईएमएस)। उपराष्ट्रपति एम वेंकैया नायडू ने प्रधानमंत्री नरेन्द्र मोदी को एक ऐसा नेता बताया जिन्होंने दुनिया को यह दिखा दिया कि सपनों को कैसे साकार किया जा सकता है। उपराष्ट्रपति एम वेंकैया नायडु ने आज, 11 मई को नई दिल्ली में ‘मोदी @20: ड्रीम्स मीट डिलीवरी’ पुस्तक का विमोचन किया। इस अवसर पर विदेश मंत्री एस जयशंकर, कई केंद्रीय मंत्री, सांसद व वरिष्ठ नेता उपस्थित थे।',
            category: 'टॉप',

        },

        {
            id: '3',
            name: 'ब्रीफ',
            url: 'https://newsreach-publishers.s3.ap-south-1.amazonaws.com/asliazadi.com/2021/04/newzealand.jpg',
            heading: 'न्यूजीलैंड में भारतीयों की एंट्री 28 अप्रैल तक बैन',
            discription: 'वेलिंगटन (ईएमएस)। कोरोना के बढ़ते मामलों को देखते हुए न्यूजीलैंड ने भारतीयों के आने पर रोक लगा दी है। भारतीयों की न्यूजीलैंड में एंट्र पर बैन 11 अप्रैल से 28 अप्रैल तक लागू रहेगा। न्यूजीलैंड की प्रधानमंत्री जैसिंडा अर्डर्न ने इसकी घोषणा करते हुए कहा कि उनके देश में पिछले 24 घंटे में कोरोना संक्रमण के 23 मामलों में से 17 भारतीय हैं।',
            category: 'ब्रीफ',

        },
        {
            id: '4',
            name: 'ब्रीफ',
            url: 'https://newsreach-publishers.s3.ap-south-1.amazonaws.com/asliazadi.com/2021/04/britain.jpg',
            heading: 'ब्रिटेन ने की अपने तीसरे कोरोना टीके की शुरूआत, लोगों से की टीका लगवाने की अपील',
            discription: 'लंदन (ईएमएस)। ब्रिटेन ने वेल्स में लोगों को मॉडर्ना कंपनी का कोविड-19 रोधी टीका लगाने की शुरुआत की। देश में दो खुराक वाला यह तीसरा टीका है जहां की राष्ट्रीय स्वास्थ्य सेवा फाइजर/बायोएनटेक और ऑक्सफोर्ड/एस्ट्राजेनेका के टीकों का पहले से ही इस्तेमाल कर रही है।',
            category: 'ब्रीफ',

        },
        {
            id: '5',
            name: 'ब्रीफ',
            url: 'https://newsreach-publishers.s3.ap-south-1.amazonaws.com/asliazadi.com/2021/04/britain.jpg',
            heading: 'ब्रिटेन ने की अपने तीसरे कोरोना टीके की शुरूआत, लोगों से की टीका लगवाने की अपील',
            discription: 'लंदन (ईएमएस)। ब्रिटेन ने वेल्स में लोगों को मॉडर्ना कंपनी का कोविड-19 रोधी टीका लगाने की शुरुआत की। देश में दो खुराक वाला यह तीसरा टीका है जहां की राष्ट्रीय स्वास्थ्य सेवा फाइजर/बायोएनटेक और ऑक्सफोर्ड/एस्ट्राजेनेका के टीकों का पहले से ही इस्तेमाल कर रही है।',
            category: 'ब्रीफ',

        },

    ])

    const [citynews, setCityNews] = useState([
        {
            id: '1',
            images: 'https://static.langimg.com/thumb/msid-92516973,imgsize-59446,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'CM गहलोत के पट्टा अभियान की ऐसे हो रही फजीहत! भूमाफियाओं के डर से दिव्यांग रिटायर्ड फौजी जमीन रजिस्ट्री के लिए भटक रहा दर दर'
        },
        {
            id: '2',
            images: 'https://static.langimg.com/thumb/msid-92495429,imgsize-66084,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'CUET 2022: इन प्वाइंस की मदद से करें यूनिवर्सिटी एंट्रेंस की तैयारी, मिलेगी सफलता'
        },
        {
            id: '3',
            images: 'https://static.langimg.com/thumb/msid-90585751,imgsize-27796,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'CUET 2022: कॉमन यूनिवर्सिटी एंट्रेंस टेस्ट के लिए कल से शुरू होंगे रजिस्ट्रेशन, ऐसे कर पाएंगे अप्लाई'
        },
        {
            id: '4',
            images: 'https://static.langimg.com/thumb/msid-90635532,imgsize-56428,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'CUET 2022 Registration: सीयूईटी के लिए 6 अप्रैल से शुरू होंगे रजिस्ट्रेशन, तैयार रखें ये डॉक्यूमेंट्स'
        },
        {
            id: '5',
            images: 'https://static.langimg.com/thumb/msid-92516973,imgsize-59446,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'CM गहलोत के पट्टा अभियान की ऐसे हो रही फजीहत! भूमाफियाओं के डर से दिव्यांग रिटायर्ड फौजी जमीन रजिस्ट्री के लिए भटक रहा दर दर'
        }
    ])
    const [currentnews, setCurrentNews] = useState({})

    const [clickedId, setClickedId] = useState('Home')
    const onPressButton = () => {

    }
    return (
        <SafeAreaView style={styles.container}>
            <ScrollView>

                <View style={{
                    width: '100%', alignSelf: 'center', flexDirection: 'row',
                    alignItems: 'center', top: vertScale(20)
                }}>
                    <View style={{ flex: 0.5, flexDirection: 'row', }}>
                        <TouchableOpacity onPress={() => {
                            navigation.navigate('homedrawer')
                        }} style={styles.Imageline}>

                            <Image style={{ width: horizScale(23), height: vertScale(20), marginLeft: horizScale(20), marginTop: vertScale(5) }}
                                source={require('../../Asset/images/drawer.png')} />
                        </TouchableOpacity>

                        <View style={{ flex: 0.4, }}>
                            <Image style={{ width: horizScale(100), height: vertScale(30), marginLeft: horizScale(50) }}
                                source={require('../../Asset/images/navbharat-times.webp')} />
                        </View>
                    </View>
                    <View style={{ flex: 0.5, flexDirection: 'row' }}>
                        <TouchableOpacity onPress={() => {
                            navigation.navigate('search')
                        }} style={{ flex: 0.2 }}>
                            <Image style={styles.Imagesearch}
                                source={require('../../Asset/images/search.png')}>
                            </Image>
                        </TouchableOpacity>

                        <TouchableOpacity onPress={() => {
                            alert('coming soon')
                        }} style={{ flex: 0.2 }}>
                            <Image style={styles.Imagebell}
                                source={require('../../Asset/images/bell.png')}>
                            </Image>
                        </TouchableOpacity>
                    </View>
                </View>


                <FlatList
                    data={news}
                    contentContainerStyle={{ paddingVertical: vertScale(20) }}
                    ItemSeparatorComponent={() => (<View style={{ height: horizScale(25) }} />)}
                    renderItem={({ item, index }) => {
                        if (clickedId == item.category || clickedId == 'Home')
                            return (
                                <View>
                                    <TouchableOpacity
                                        activeOpacity={0.8}
                                        onPress={() => {
                                            navigation.navigate('detailed', { news: item })
                                        }}
                                        style={styles.newsContainer}
                                    >
                                        <View style={{ flex: 0.33 }}>
                                            <Image style={styles.images}
                                                source={{ uri: item.url }}></Image>
                                        </View>
                                        <View style={{
                                            flex: 0.67, backgroundColor: Customcolor.white, marginLeft: horizScale(10),
                                            borderRadius: 10,
                                        }}>
                                            <Text style={styles.overlytext}>{item.heading}</Text>
                                        </View>
                                    </TouchableOpacity>
                                    {index == 2 ? <View style={{ flex: 1, backgroundColor: Customcolor.white, marginTop: 40, elevation: 4 }}>
                                        <View style={{ flex: 1, flexDirection: 'row' }}>
                                            <View style={{ flex: 2 }}>
                                                <Text style={{
                                                    color: Customcolor.black, fontSize: fontSize.h6,
                                                    marginLeft: 20, marginTop: vertScale(20), alignSelf: 'flex-start',
                                                    fontWeight: '600'
                                                }}>{'राज्य'}</Text>
                                            </View>
                                            <View style={{ flex: 4 }}>
                                                <Text style={{
                                                    color: Customcolor.black, fontSize: fontSize.h6,
                                                    marginLeft: 20, marginTop: vertScale(20), alignSelf: 'flex-end',
                                                    fontWeight: '600'
                                                }}>{'और देखें'}</Text>
                                            </View>
                                            <View style={{ flex: 1 }}>
                                                <Image style={{
                                                    width: horizScale(16), height: vertScale(16),
                                                    marginLeft: 20, marginTop: vertScale(25), alignSelf: 'flex-start'
                                                }}
                                                    source={require('../../Asset/images/nest.png')} />
                                            </View>

                                        </View>
                                        <FlatList
                                            data={citynews}
                                            contentContainerStyle={{
                                                paddingVertical: vertScale(10),
                                                backgroundColor: Customcolor.white,
                                                elevation: 5,
                                                // marginTop: 70,
                                            }}

                                            renderItem={({ item }) => {
                                                if (clickedId == item.category || clickedId == 'Home')
                                                    return (

                                                        <TouchableOpacity
                                                            activeOpacity={0.8}
                                                            onPress={() => {
                                                                navigation.navigate('detailed', { news: item })
                                                            }}
                                                            style={{
                                                                paddingVertical: horizScale(10),
                                                                marginHorizontal: horizScale(15),

                                                            }}
                                                        >


                                                            <Image style={{
                                                                flex: 1,
                                                                padding: 70,
                                                                resizeMode: 'contain'
                                                            }}
                                                                source={{ uri: item.images }} />
                                                            <Text style={{
                                                                width: horizScale(200),
                                                                height: vertScale(50),
                                                                color: Customcolor.black,
                                                                marginTop: 10,
                                                            }}>
                                                                {item.heading}</Text>

                                                        </TouchableOpacity>
                                                    )
                                            }}
                                            keyExtractor={(item) => item.id}
                                            horizontal
                                        />
                                    </View>
                                        : null}
                                </View>
                            )
                    }}
                    keyExtractor={(item) => item.id}
                />


                <FlatList
                    data={news}
                    contentContainerStyle={{ paddingVertical: vertScale(20) }}
                    ItemSeparatorComponent={() => (<View style={{ height: horizScale(25) }} />)}
                    renderItem={({ item, index }) => {
                        if (clickedId == item.category || clickedId == 'Home')
                            return (
                                <View>
                                    <TouchableOpacity
                                        activeOpacity={0.8}
                                        onPress={() => {
                                            navigation.navigate('detailed', { news: item })
                                        }}
                                        style={styles.newsContainer}
                                    >
                                        <View style={{ flex: 0.33 }}>
                                            <Image style={styles.images}
                                                source={{ uri: item.url }}></Image>
                                        </View>
                                        <View style={{
                                            flex: 0.67, backgroundColor: Customcolor.white, marginLeft: horizScale(10),
                                            borderRadius: 10,
                                        }}>
                                            <Text style={styles.overlytext}>{item.heading}</Text>
                                        </View>
                                    </TouchableOpacity>
                                    {index == 2 ? <View style={{ flex: 1, backgroundColor: Customcolor.white, marginTop: 40, elevation: 4 }}>
                                        <View style={{ flex: 1, flexDirection: 'row' }}>
                                            <View style={{ flex: 2 }}>
                                                <Text style={{
                                                    color: Customcolor.black, fontSize: fontSize.h6,
                                                    marginLeft: 20, marginTop: vertScale(20), alignSelf: 'flex-start',
                                                    fontWeight: '600'
                                                }}>{'राज्य'}</Text>
                                            </View>
                                            <View style={{ flex: 4 }}>
                                                <Text style={{
                                                    color: Customcolor.black, fontSize: fontSize.h6,
                                                    marginLeft: 20, marginTop: vertScale(20), alignSelf: 'flex-end',
                                                    fontWeight: '600'
                                                }}>{'और देखें'}</Text>
                                            </View>
                                            <View style={{ flex: 1 }}>
                                                <Image style={{
                                                    width: horizScale(16), height: vertScale(16),
                                                    marginLeft: 20, marginTop: vertScale(25), alignSelf: 'flex-start'
                                                }}
                                                    source={require('../../Asset/images/nest.png')} />
                                            </View>

                                        </View>
                                        <FlatList
                                            data={citynews}
                                            contentContainerStyle={{
                                                paddingVertical: vertScale(10),
                                                backgroundColor: Customcolor.white,
                                                elevation: 5,
                                                // marginTop: 70,
                                            }}

                                            renderItem={({ item }) => {
                                                if (clickedId == item.category || clickedId == 'Home')
                                                    return (

                                                        <TouchableOpacity
                                                            activeOpacity={0.8}
                                                            onPress={() => {
                                                                navigation.navigate('detailed', { news: item })
                                                            }}
                                                            style={{
                                                                paddingVertical: horizScale(10),
                                                                marginHorizontal: horizScale(15),

                                                            }}
                                                        >


                                                            <Image style={{
                                                                flex: 1,
                                                                padding: 70,
                                                                resizeMode: 'contain'
                                                            }}
                                                                source={{ uri: item.images }} />
                                                            <Text style={{
                                                                width: horizScale(200),
                                                                height: vertScale(50),
                                                                color: Customcolor.black,
                                                                marginTop: 10,
                                                            }}>
                                                                {item.heading}</Text>

                                                        </TouchableOpacity>
                                                    )
                                            }}
                                            keyExtractor={(item) => item.id}
                                            horizontal
                                        />
                                    </View>
                                        : null}
                                </View>
                            )
                    }}
                    keyExtractor={(item) => item.id}
                />


            </ScrollView>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    newsContainer: {
        flexDirection: 'row',
        backgroundColor: Customcolor.white,
        paddingVertical: horizScale(15),
        marginHorizontal: horizScale(15),
        borderRadius: horizScale(15),
        elevation: 5,
        top: 30
    },
    container: {
        flex: 1,
        backgroundColor: Customcolor.lightwhite,

    },
    Imageline: {
        flex: 0.1,
        width: horizScale(30),
        height: vertScale(30),
    },

    Imagesearch: {
        width: horizScale(20),
        height: vertScale(20),
        marginLeft: horizScale(115)
    },
    Imagebell: {
        width: horizScale(20),
        height: vertScale(20),
        marginLeft: horizScale(110)
    },

    images: {
        width: '90%',
        height: vertScale(90),
        resizeMode: "cover",
        borderRadius: horizScale(5),
        alignSelf: 'center'
    },
    overlytext: {
        color: Customcolor.black,
        fontSize: fontSize.medium,
        fontWeight: "700",
    }

})

export default MycityScreentab;