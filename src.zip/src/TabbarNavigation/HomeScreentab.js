import React, { useState } from 'react';
import {
    View, Text, FlatList,
    StyleSheet,
    ScrollView,
    SafeAreaView,
    Image,
    ImageBackground,
    TouchableOpacity,
    Button,
    StatusBar,
} from 'react-native';
import { Customcolor } from '../Utility/Customcolor';
import { Customimage } from '../Utility/Customimage';
import { fontSize } from '../Utility/Fontsize';
import { horizScale, Layout, vertScale } from '../Utility/Layout';


const HomeScreentab = ({ navigation }) => {
    const [selectednews, setselectednews] = useState();

    const [category, setcategory] = useState([
        'सभी',
        'टॉप',
        'ब्रीफ',
        'वेब स्टोरी',
        'रेक्मेंडे',
        'भारत',
        'राज्य',
        'अपना बाजार',
        'मेट्रो',
        'गुड न्यूज',
        'Viral',
        'मूवी',
        'लाइफस्टाइल',
        'दुनिया',
        'बिजनेस',
        'खेल',
        'ऑटो',
        'टेक',
        'एजुकेशन',
        'और',



    ])

    const [news, setnews] = useState([
        {
            id: '1',
            name: 'टॉप',
            url: 'https://newsreach-publishers.s3.ap-south-1.amazonaws.com/asliazadi.com/2022/05/Samuh-Lagan-.jpeg',
            heading: 'धरमपुर के हथनबारी गांव में 25 आदिवासी जोडों के समूह लग्न में उपस्थित रहे संघ प्रदेश थ्रीडी भाजपा ओबीसी मोर्चा अध्यक्ष हरीश पटेल',
            discription: 'असली आजादी न्यूज नेटवर्क, धरमपुर 23 मई। गुजरात के धरमपुर तालुका के आंतरिक क्षेत्र में स्थित आदिवासी बहुल गांव हथनबारी में आज श्री कृष्ण परिवार और विश्व विख्यात कथाकार मेहुल जानी द्वारा 25 आदिवासी जोडों के लिए समूह लग्न का आयोजन किया गया था। गरीब आदिवासी परिवार की 25 बेटियां और 25 बेटे कथाकार मेहुल जानी का आशीर्वाद लेकर शादी के अटूट बंधन में बंध गये।',
            category: 'टॉप',

        },
        {
            id: '2',
            name: 'टॉप',
            url: 'https://newsreach-publishers.s3.ap-south-1.amazonaws.com/asliazadi.com/2022/05/Amit-Shah-Book-1.jpg',
            heading: 'पीएम मोदी की प्रामाणिकता और पारदर्शिता पर विरोधी भी नहीं उठा सकते उंगली : शाह',
            discription: 'नई दिल्ली (ईएमएस)। उपराष्ट्रपति एम वेंकैया नायडू ने प्रधानमंत्री नरेन्द्र मोदी को एक ऐसा नेता बताया जिन्होंने दुनिया को यह दिखा दिया कि सपनों को कैसे साकार किया जा सकता है। उपराष्ट्रपति एम वेंकैया नायडु ने आज, 11 मई को नई दिल्ली में ‘मोदी @20: ड्रीम्स मीट डिलीवरी’ पुस्तक का विमोचन किया। इस अवसर पर विदेश मंत्री एस जयशंकर, कई केंद्रीय मंत्री, सांसद व वरिष्ठ नेता उपस्थित थे।',
            category: 'टॉप',

        },
        {
            id: '3',
            name: 'टॉप',
            url: 'https://newsreach-publishers.s3.ap-south-1.amazonaws.com/asliazadi.com/2022/03/Ashvini-praful-patel.jpeg',
            heading: 'केंद्रीय रेलवे, संचार एवं आईटी मंत्री अश्विनी वैष्णव से प्रशासक प्रफुल पटेल ने की मुलाकात',
            discription: '– प्रशासक प्रफुल पटेल ने संघ प्रदेश थ्रीडी के विकासलक्षी मुद्दों और आगामी प्रोजेक्टों पर की चर्चा असली आजादी न्यूज नेटवर्क, नई दिल्ली 05 मार्च। संघ प्रदेश दादरा एवं नगर हवेली और दमण- दीव तथा लक्षद्वीप के प्रशासक प्रफुल पटेल द्वारा नई दिल्ली में केंद्रीय मंत्रियों के साथ मुलाकात करने का सिलसिला जारी है। ',
            category: 'टॉप',



        },
        {
            id: '4',
            name: 'टॉप',
            url: 'https://newsreach-publishers.s3.ap-south-1.amazonaws.com/asliazadi.com/2022/02/daman-diu-police-2.jpg',
            heading: 'संघ प्रदेश दादरा नगर हवेली और दमण-दीव पुलिस विभाग के 2 आईपीएस एसपी अमित शर्मा और अनुज कुमार को मिला पुलिस वीरता पुरस्कार',
            discription: '– दिल्ली में सीएए और एनआरसी के खिलाफ दंगों को रोकने वाले – दिल्ली पुलिस के 75वें स्थापना दिवस पर आयोजित समारोह में गृहमंत्री अमित शाह ने दमण एसपी अमित शर्मा और दीव एसपी अनुज कुमार को किया सम्मानित असली आजादी न्यूज नेटवर्क, नई दिल्ली/ दमण / दीव 16 फरवरी। ',
            category: 'टॉप',



        },
        {
            id: '5',
            name: 'ब्रीफ',
            url: 'https://newsreach-publishers.s3.ap-south-1.amazonaws.com/asliazadi.com/2021/04/newzealand.jpg',
            heading: 'न्यूजीलैंड में भारतीयों की एंट्री 28 अप्रैल तक बैन',
            discription: 'वेलिंगटन (ईएमएस)। कोरोना के बढ़ते मामलों को देखते हुए न्यूजीलैंड ने भारतीयों के आने पर रोक लगा दी है। भारतीयों की न्यूजीलैंड में एंट्र पर बैन 11 अप्रैल से 28 अप्रैल तक लागू रहेगा। न्यूजीलैंड की प्रधानमंत्री जैसिंडा अर्डर्न ने इसकी घोषणा करते हुए कहा कि उनके देश में पिछले 24 घंटे में कोरोना संक्रमण के 23 मामलों में से 17 भारतीय हैं।',
            category: 'ब्रीफ',

        },
        {
            id: '6',
            name: 'ब्रीफ',
            url: 'https://newsreach-publishers.s3.ap-south-1.amazonaws.com/asliazadi.com/2021/04/britain.jpg',
            heading: 'ब्रिटेन ने की अपने तीसरे कोरोना टीके की शुरूआत, लोगों से की टीका लगवाने की अपील',
            discription: 'लंदन (ईएमएस)। ब्रिटेन ने वेल्स में लोगों को मॉडर्ना कंपनी का कोविड-19 रोधी टीका लगाने की शुरुआत की। देश में दो खुराक वाला यह तीसरा टीका है जहां की राष्ट्रीय स्वास्थ्य सेवा फाइजर/बायोएनटेक और ऑक्सफोर्ड/एस्ट्राजेनेका के टीकों का पहले से ही इस्तेमाल कर रही है।',
            category: 'ब्रीफ',

        },
        {
            id: '7',
            name: 'ब्रीफ',
            url: 'https://newsreach-publishers.s3.ap-south-1.amazonaws.com/asliazadi.com/2021/04/northkorea.jpg',
            heading: 'उ.कोरिया का दावा, डब्ल्यूएचओ से कहा- देश में कोरोना का एक भी मामला नहीं',
            discription: 'सियोल (ईएमएस)। उत्तर कोरिया ने विश्व स्वास्थ्य संगठन (डब्ल्यूएचओ) को पेश की कई अपनी हालिया रिपोर्ट में दावा किया है कि देश अब भी कोरोना वायरस से मुक्त है। उत्तर कोरिया ने करीब एक साल पहले संक्रमण की शुरुआत में देश को महामारी से मुक्त रखने के प्रयास को ‘‘राष्ट्र के अस्तित्व का सवाल’’ करार दिया था। ',
            category: 'ब्रीफ',

        },
        {
            id: '8',
            name: 'वेब स्टोरी',
            url: 'https://newsreach-publishers.s3.ap-south-1.amazonaws.com/asliazadi.com/2022/06/Praful-Patel-Visit-DMN-01-960x640.jpg',
            heading: 'प्रशासक प्रफुल पटेल ने दमण में ग्राउंड जीरो पर विकास प्रोजेक्टों की समीक्षा की',
            discription: 'असली आजादी न्यूज नेटवर्क, दमण 19 जून। दमण में मानसून की दस्तक के बीच संघ प्रदेश दादरा एवं नगर हवेली और दमण-दीव तथा लक्षद्वीप के प्रशासक प्रफुल पटेल ने अपने अधीनस्थ अधिकारियों के साथ दमण में चल रहे विभिन्न विकासीय प्रोजेक्टों की ग्राउंड जीरो पर पहुंचकर समीक्षा की।',
            category: 'वेब स्टोरी',

        },
        {
            id: '9',
            name: 'वेब स्टोरी',
            url: 'https://newsreach-publishers.s3.ap-south-1.amazonaws.com/asliazadi.com/2022/06/Shoukat-Mithani-03-960x449.jpg',
            heading: 'संघ प्रदेश थ्रीडी भाजपा अल्पसंख्यक मोर्चा की चौपाल में अल्पसंख्यक मोर्चा के राष्ट्रीय सचिव सैयद इब्राहिम हुए शामिल',
            discription: 'असली आजादी न्यूज नेटवर्क, दमण 13 जून। मोदी सरकार के 8 वर्ष पूरे होने पर भारतीय जनता पार्टी के राष्ट्रीय अल्पसंख्यक मोर्चा द्वारा दिये गये दिशा-निर्देश एवं संघ प्रदेश थ्रीडी भाजपा प्रभारी विजया रहाटकर, भाजपा प्रदेश अध्यक्ष दीपेश टंडेल तथा संगठन महामंत्री विवेक दाढकर के मार्गदर्शन में संघ प्रदेश थ्रीडी भाजपा ',
            category: 'वेब स्टोरी',

        },
        {
            id: '10',
            name: 'वेब स्टोरी',
            url: 'https://newsreach-publishers.s3.ap-south-1.amazonaws.com/asliazadi.com/2022/06/Torrent-Power-DNHDD-Logo.jpg',
            heading: 'टोरेंट पावर को डीएनएच डीडी पीडीसीएल के नाम पर चाहिए लोन 1500 करोड रुपये का, ब्याज भरेगी जनता?',
            discription: 'असली आजादी न्यूज नेटवर्क, दमण 17 जून। टोरेंट पावर कंपनी ने संघ प्रदेश दादरा एवं नगर हवेली और दमण-दीव की डीएनएच डीडी पावर डिस्ट्रीब्यूशन कॉर्पोरेशन लि. की 51% हिस्सेदारी खरीदकर संघ प्रदेश की बिजली वितरण व्यवस्था एवं खुदरा कारोबार का ठेका हासिल तो कर लिया लेकिन इस निगम को चलाने के लिए निवेश के नाम पर टोरेंट पावर शायद ठंेगा ही दिखा रहा है। ',
            category: 'वेब स्टोरी',

        },
        {
            id: '11',
            name: 'रेक्मेंडे',
            url: 'https://newsreach-publishers.s3.ap-south-1.amazonaws.com/asliazadi.com/2021/04/britain1-960x959.jpg',
            heading: 'ब्रिटेन में अब 30 वर्ष से कम उम्र के लोगों को वैक्सीन का दूसरा विकल्प मिलेगा',
            discription: 'लंदन (ईएमएस)। ब्रिटेन में रक्त के थक्के बनने की चिंता के बीच 30 वर्ष से कम उम्र के लोगों को वैक्सीन का दूसरा विकल्प चुनने की आज़ादी होगी। ब्रिटेन की एक स्वास्थ्य समिति ने सिफारिश की है कि 18 से 29 वर्ष के आय़ु वर्ग के युवाओं को एस्ट्राजेनेका की जगह कोरोना की दूसरी वैक्सीन का विकल्प मिलना चाहिए।',
            category: 'रेक्मेंडे',



        },
        {
            id: '12',
            name: 'रेक्मेंडे',
            url: 'https://newsreach-publishers.s3.ap-south-1.amazonaws.com/asliazadi.com/2022/06/H20220611113471-960x640.jpg',
            heading: 'सहकारी संघवाद की भावना से राष्ट्र के सर्वांगीण विकास के प्रति मोदी सरकार के संकल्प और कटिबद्धता को दर्शाता है : अमित शाह',
            discription: 'दीव (पीआईबी)। केन्द्रीय गृह एवं सहकारिता मंत्री श्री अमित शाह ने आज दीव में पश्चिमी क्षेत्रीय परिषद की 25वीं बैठक की अध्यक्षता की। बैठक में गोवा, गुजरात के मुख्यमंत्री और दादरा और नगर हवेली और दमन और दीव के प्रशासकों, गुजरात और महाराष्ट्र के वरिष्ठ मंत्रियों, केन्द्रीय गृह सचिव, पश्चिमी क्षेत्र के सदस्य राज्यों के मुख्य सचिव, सचिव, अंतरराज्यीय',
            category: 'रेक्मेंडे',



        },
        {
            id: '13',
            name: 'खेल',
            url: 'https://images.hindi.news18.com/ibnkhabar/uploads/2021/09/t20.jpg',
            heading: 'टी-20 विश्व कप का आयोजन तय कार्यक्रम के अनुसार',
            discription: 'दुबई। आईसीसी के अंतरिम मुख्य कार्यकारी अधिकारी (सीईओ) ज्योफ अलार्डिस ने कहा कि उनके पास इस साल के अंत में भारत में होने वाले टी-20 विश्व कप के लिए ‘बैकअपÓ (दूसरी) योजना है। इस समय यहां कोविड-19 मामलों में बढ़ोतरी के बावजूद देश से इसे हटाने के किसी भी विचार के बारे में नहीं सोच रहे हैं। टी-20 विश्व कप का आयोजन भारत में अक्तूबर-नवंबर में होगा।',
            category: 'खेल',



        },
        {
            id: '14',
            name: 'खेल',
            url: 'https://static.punjabkesari.in/multimedia/15_51_424373296hockey-2.jpg',
            heading: 'भारतीय पुरुष हॉकी टीम ने अर्जेंटीना को 4-3 से हराया',
            discription: 'ब्यूनस आयर्स (ईएमएस)। भारतीय पुरुष हॉकी टीम ने अर्जेन्टीना दौरे की सकारात्मक शुरुआत करते हुए गत ओलंपिक चैंपियन को यहां पहले अभ्यास मैच में 4-3 से हरा दिया है। निलाकांत शर्मा (16वें मिनट), हरमनप्रीत सिंह (28वें मिनट), रूपिंदर पाल सिंह (33वें मिनट) और वरूण कुमार (47वें मिनट) ने मंगलवार रात हुए मुकाबले में भारत की ओर से गोल दागे',
            category: 'खेल',



        },
        {
            id: '15',
            name: 'खेल',
            url: 'https://akm-img-a-in.tosshub.com/aajtak/images/story/202011/virat_kohli_rsb_vs_dc-sixteen_nine.jpg?size=948:533',
            heading: 'आईपीएल का पहला मुकाबला कल, मुंबई से भिड़ेगी आरसीबी',
            discription: 'मुंबई । आईपीएल 14 का आगाज शुक्रवार से होने जा रहा है। पहला मुकाबला मुंबई इंडियंस और रॉयल चैलेंजर बेंगलुरू के बीच होगा। इस महामुकाबले के लिए रोहित शर्मा और विराट कोहली की टीमें पूरी तरह तैयार है। कोरोना महामारी के कारण पिछली बार आईपीएल का आयोजन भारत में नहीं हो पाया था,',
            category: 'खेल',



        },
        {
            id: '16',
            name: 'भारत',
            url: 'https://ichef.bbci.co.uk/images/ic/400x225_b/p013fkwy.jpg',
            heading: 'बीबीसी वर्ल्ड न्यूज़ ने नए स्टूडियो, नई प्रोग्रामिंग और नए प्रस्तुतकर्ता लॉन्च किए',
            discription: 'अमेरिका और बर्मा में महत्वपूर्ण नए वितरण सौदों की घोषणा करने के बाद, बीबीसी का अंतर्राष्ट्रीय टेलीविजन समाचार चैनल, बीबीसी वर्ल्ड न्यूज़, अगले सप्ताह एक नाटकीय नए रूप का अनावरण कर रहा है, जब यह मध्य लंदन में नए स्टूडियो से फिर से लॉन्च होगा।',
            category: 'भारत',



        },
        {
            id: '17',
            name: 'भारत',
            url: 'https://newsgallery.in/wp-content/uploads/2022/06/1401200796w5ykAujrME4h-800x445.jpg',
            heading: 'महारानी एलिजाबेथ द्वितीय ने व्यक्तिगत रूप से ऐतिहासिक जयंती समाप्त करने का संकल्प लिया',
            discription: 'सम्राट ने कहा कि वह अपने प्लेटिनम जुबली समारोह के लिए "विनम्र और गहराई से छुआ" गया था और "दया, खुशी और रिश्तेदारी से प्रेरित था जो हाल के दिनों में इतना स्पष्ट है"',
            category: 'भारत',



        },
        {
            id: '18',
            name: 'बिजनेस',
            url: 'https://newsreach-publishers.s3.ap-south-1.amazonaws.com/asliazadi.com/2021/04/indiagdp.jpg',
            heading: '90 फीसदी के रिकॉर्ड स्तर पर पहुंचा भारत का कर्ज-जीडीपी अनुपात',
            discription: 'बई (ईएमएस)। अंतरराष्ट्रीय मौद्रिक कोष ने कहा कि कोरोना महामारी के दौरान भारत का ऋण-जीडीपी अनुपात 74 प्रतिशत से बढ़कर 90 प्रतिशत हो गया और उम्मीद जताई की आर्थिक सुधार के साथ ही ये घटकर 80 प्रतिशत पर आ सकता है। आईएफएफ के राजकोषीय मामलों के विभाग के उप निदेशक पाओलो मौरो ने कहा कि भारत के मामले में, महामारी से पहले 2019 के आ‎खिर में ऋण अनुपात सकल घरेलू उत्पाद (जीडीपी) का 74 प्रतिशत था',
            category: 'बिजनेस',



        },
        {
            id: '19',
            name: 'बिजनेस',
            url: 'https://newsreach-publishers.s3.ap-south-1.amazonaws.com/asliazadi.com/2021/04/wallet.jpg',
            heading: 'पेटीएम, फ्रीचार्ज जैसे मोबाइल वॉलेट से पेमेंट की लिमिट हुई दोगुनी',
            discription: 'नई दिल्ली (ईएमएस)। भारतीय रिजर्व बैंक (आरबीआई) ने वित्त वर्ष 2021-22 की पहली मौद्रिक समीक्षा में अहम फैसला लिया। आरबीआई ने डिजिटल पेमेंट कंपनियों जैसे पेटीएम-फोनपे जैसे के लिए लिमिट को बढ़ाकर दोगुनी कर दिया। यानी अब वॉलेट में 1 लाख रुपए की जगह 2 लाख रुपए रखने की सुविधा उपभोक्तओं को मिलेगी।',
            category: 'बिजनेस',

        },
        {
            id: '20',
            name: 'बिजनेस',
            url: 'https://newsreach-publishers.s3.ap-south-1.amazonaws.com/asliazadi.com/2021/04/gold21.jpg',
            heading: 'सोना सस्ता, चांदी महंगी',
            discription: 'मुंबई (ईएमएस)। सोना और चांदी में एक बार फिर खरीदारी का मौका बनता दिख रहा है। बुधवार की शानदार तेजी के बाद गुरुवार को इसमें एक बार फिर सुस्ती देखी जा रही है। एमसीएक्स पर सोना हल्की सुस्ती के साथ शुरू हुआ है, हालांकि इसमें कमजोरी धीरे-धीरे बढ़ती दिख रही है।',
            category: 'बिजनेस',
        },
        {
            id: '21',
            name: 'राज्य',
            url: 'https://hindi.hlives.com/content/images/2018/12/Pati-Patni-Ka-Rishta.jpg',
            heading: 'पति सोचेंगे',
            discription: 'फिर शॉपिंग का चक्कर, फिर मूवी की फरमाइश…फिर वीक एंड पर होटलिंग , फिर घूमने जाने की बच्चों की फरमाईश , बीबी की नई साड़ी की डिमांड , किटी पार्टी के चक्कर , नई ज्वैलरी खरीदने की जिद्द .. इससे तो कोरोना ही भला था . न रिश्तेदारी में भागमभाग करनी पड़ती थी , न आफिस के दौरे करने परते थे , न बाजार जाकर चुन बीन कर देख भाल कर खरीददारी होती थी ,सब कुछ मोबाईल से निपट जाता था ',
            category: 'राज्य',


        },
        {
            id: '22',
            name: 'राज्य',
            url: 'https://hindi.hlives.com/content/images/2018/12/Pati-Patni-Ka-Rishta.jpg',
            heading: 'पति सोचेंगे',
            discription: 'फिर शॉपिंग का चक्कर, फिर मूवी की फरमाइश…फिर वीक एंड पर होटलिंग , फिर घूमने जाने की बच्चों की फरमाईश , बीबी की नई साड़ी की डिमांड , किटी पार्टी के चक्कर , नई ज्वैलरी खरीदने की जिद्द .. इससे तो कोरोना ही भला था . न रिश्तेदारी में भागमभाग करनी पड़ती थी , न आफिस के दौरे करने परते थे , न बाजार जाकर चुन बीन कर देख भाल कर खरीददारी होती थी ,सब कुछ मोबाईल से निपट जाता था ',
            category: 'राज्य',


        },
        {
            id: '23',
            name: 'राज्य',
            url: 'https://hindi.hlives.com/content/images/2018/12/Pati-Patni-Ka-Rishta.jpg',
            heading: 'पति सोचेंगे',
            discription: 'फिर शॉपिंग का चक्कर, फिर मूवी की फरमाइश…फिर वीक एंड पर होटलिंग , फिर घूमने जाने की बच्चों की फरमाईश , बीबी की नई साड़ी की डिमांड , किटी पार्टी के चक्कर , नई ज्वैलरी खरीदने की जिद्द .. इससे तो कोरोना ही भला था . न रिश्तेदारी में भागमभाग करनी पड़ती थी , न आफिस के दौरे करने परते थे , न बाजार जाकर चुन बीन कर देख भाल कर खरीददारी होती थी ,सब कुछ मोबाईल से निपट जाता था ',
            category: 'राज्य',


        },
        {
            id: '24',
            name: 'अपना बाजार',
            url: 'https://youtu.be/fHLXQuudHZE',
            heading: 'दमण जिला पंचायत उपप्रमुख मैत्री पटेल की अपील',
            discription: 'असली आजादी न्यूज नेटवर्क, दीव 28 अप्रैल। साउदवाडी ग्राम पंचायत में प्रशासन द्वारा चल रहे विभिन्न कार्यों को लेकर आज साउदवाडी ग्राम पंचायत सरपंच शंकर बारैया, दीव जिला सदस्य पंचायत उमेश बामणिया एवं रामजी बामणिया ने दमण पहुंचकर प्रशासक प्रफुल पटेल से शुभेच्छा मुलाकात की। ',
            category: 'अपना बाजार',


        },
        {
            id: '25',
            name: 'अपना बाजार',
            url: 'https://youtu.be/kDSRd1ukY1Y',
            heading: 'दादरा नगर हवेली स्वामिनारायण (BAPS) चिन्मय दास स्वामी की अपील',
            discription: 'असली आजादी न्यूज नेटवर्क, दीव 28 अप्रैल। साउदवाडी ग्राम पंचायत में प्रशासन द्वारा चल रहे विभिन्न कार्यों को लेकर आज साउदवाडी ग्राम पंचायत सरपंच शंकर बारैया, दीव जिला सदस्य पंचायत उमेश बामणिया एवं रामजी बामणिया ने दमण पहुंचकर प्रशासक प्रफुल पटेल से शुभेच्छा मुलाकात की। ',
            category: 'अपना बाजार',


        },
        {
            id: '26',
            name: 'अपना बाजार',
            url: 'https://youtu.be/Rd_BPqrw9jw',
            heading: 'दादरा नगर हवेली के पूर्व सांसद और भाजपा नेता नटू पटेल की अपील',
            discription: 'असली आजादी न्यूज नेटवर्क, दीव 28 अप्रैल। साउदवाडी ग्राम पंचायत में प्रशासन द्वारा चल रहे विभिन्न कार्यों को लेकर आज साउदवाडी ग्राम पंचायत सरपंच शंकर बारैया, दीव जिला सदस्य पंचायत उमेश बामणिया एवं रामजी बामणिया ने दमण पहुंचकर प्रशासक प्रफुल पटेल से शुभेच्छा मुलाकात की। ',
            category: 'अपना बाजार',


        },
        {
            id: '27',
            name: 'अपना बाजार',
            url: 'https://youtu.be/6ZbisniH-lI',
            heading: 'डीआईए वाईस प्रेसिडेंट पवन अग्रवाल की अपील',
            discription: 'असली आजादी न्यूज नेटवर्क, दीव 28 अप्रैल। साउदवाडी ग्राम पंचायत में प्रशासन द्वारा चल रहे विभिन्न कार्यों को लेकर आज साउदवाडी ग्राम पंचायत सरपंच शंकर बारैया, दीव जिला सदस्य पंचायत उमेश बामणिया एवं रामजी बामणिया ने दमण पहुंचकर प्रशासक प्रफुल पटेल से शुभेच्छा मुलाकात की। ',
            category: 'अपना बाजार',


        },
        {
            id: '28',
            name: 'मेट्रो',
            url: 'https://youtu.be/6ZbisniH-lI',
            heading: 'डीआईए वाईस प्रेसिडेंट पवन अग्रवाल की अपील',
            discription: 'असली आजादी न्यूज नेटवर्क, दीव 28 अप्रैल। साउदवाडी ग्राम पंचायत में प्रशासन द्वारा चल रहे विभिन्न कार्यों को लेकर आज साउदवाडी ग्राम पंचायत सरपंच शंकर बारैया, दीव जिला सदस्य पंचायत उमेश बामणिया एवं रामजी बामणिया ने दमण पहुंचकर प्रशासक प्रफुल पटेल से शुभेच्छा मुलाकात की। ',
            category: 'मेट्रो',


        },
        {
            id: '29',
            name: 'मेट्रो',
            url: 'https://youtu.be/6ZbisniH-lI',
            heading: 'डीआईए वाईस प्रेसिडेंट पवन अग्रवाल की अपील',
            discription: 'असली आजादी न्यूज नेटवर्क, दीव 28 अप्रैल। साउदवाडी ग्राम पंचायत में प्रशासन द्वारा चल रहे विभिन्न कार्यों को लेकर आज साउदवाडी ग्राम पंचायत सरपंच शंकर बारैया, दीव जिला सदस्य पंचायत उमेश बामणिया एवं रामजी बामणिया ने दमण पहुंचकर प्रशासक प्रफुल पटेल से शुभेच्छा मुलाकात की। ',
            category: 'मेट्रो',
        },
        {
            id: '30',
            name: 'मेट्रो',
            url: 'https://youtu.be/6ZbisniH-lI',
            heading: 'डीआईए वाईस प्रेसिडेंट पवन अग्रवाल की अपील',
            discription: 'असली आजादी न्यूज नेटवर्क, दीव 28 अप्रैल। साउदवाडी ग्राम पंचायत में प्रशासन द्वारा चल रहे विभिन्न कार्यों को लेकर आज साउदवाडी ग्राम पंचायत सरपंच शंकर बारैया, दीव जिला सदस्य पंचायत उमेश बामणिया एवं रामजी बामणिया ने दमण पहुंचकर प्रशासक प्रफुल पटेल से शुभेच्छा मुलाकात की। ',
            category: 'मेट्रो',


        },

        {
            id: '31',
            name: 'गुड न्यूज',
            url: 'https://newsreach-publishers.s3.ap-south-1.amazonaws.com/asliazadi.com/2021/04/Demo_News_16-11.jpg',
            heading: 'सीबीएसई 12वीं की गणित परीक्षा की ऐसे करें तैयारी',
            discription: 'परीक्षाएं करीब है और ऐसे में छात्रों पर तैयारी का दबाव है। सीबीएसई 12वीं में गणित के पेपर की तैयारी बेहद महत्वपूर्ण होती है क्योंकि 12वें के गणित संबंधित प्रश्न कई प्रतिस्पर्धी परीक्षाओं में भी पूछे जाते हैं। गणित को सबसे कठिन विषय माना जाता है। अगर आप गणित के पेपर के लिए पूरी और सही तैयारी करेंगे तो ये कई प्रतिस्पर्धी परीक्षाओं में भी आपके काम आएगी।',
            category: 'गुड न्यूज',


        },
        {
            id: '32',
            name: 'गुड न्यूज',
            url: 'https://newsreach-publishers.s3.ap-south-1.amazonaws.com/asliazadi.com/2021/04/Demo_News_16-11.jpg',
            heading: 'सीबीएसई 12वीं की गणित परीक्षा की ऐसे करें तैयारी',
            discription: 'परीक्षाएं करीब है और ऐसे में छात्रों पर तैयारी का दबाव है। सीबीएसई 12वीं में गणित के पेपर की तैयारी बेहद महत्वपूर्ण होती है क्योंकि 12वें के गणित संबंधित प्रश्न कई प्रतिस्पर्धी परीक्षाओं में भी पूछे जाते हैं। गणित को सबसे कठिन विषय माना जाता है। अगर आप गणित के पेपर के लिए पूरी और सही तैयारी करेंगे तो ये कई प्रतिस्पर्धी परीक्षाओं में भी आपके काम आएगी।',
            category: 'गुड न्यूज',


        },
        {
            id: '33',
            name: 'गुड न्यूज',
            url: 'https://newsreach-publishers.s3.ap-south-1.amazonaws.com/asliazadi.com/2021/04/Demo_News_16-11.jpg',
            heading: 'सीबीएसई 12वीं की गणित परीक्षा की ऐसे करें तैयारी',
            discription: 'परीक्षाएं करीब है और ऐसे में छात्रों पर तैयारी का दबाव है। सीबीएसई 12वीं में गणित के पेपर की तैयारी बेहद महत्वपूर्ण होती है क्योंकि 12वें के गणित संबंधित प्रश्न कई प्रतिस्पर्धी परीक्षाओं में भी पूछे जाते हैं। गणित को सबसे कठिन विषय माना जाता है। अगर आप गणित के पेपर के लिए पूरी और सही तैयारी करेंगे तो ये कई प्रतिस्पर्धी परीक्षाओं में भी आपके काम आएगी।',
            category: 'गुड न्यूज',

        },
        {
            id: '34',
            name: 'Viral',
            url: 'https://uonlibrary.uonbi.ac.ke/sites/uonlibrary.uonbi.ac.ke/files/styles/large/public/2022-02/e-paper.jpeg?itok=pDd6FcRT',
            heading: 'मानक और राष्ट्र ई- समाचार पत्र कैसे प्राप्त करें',
            discription: 'वर्तमान जागरूकता सूचना तक पहुंच बढ़ाने के लिए विश्वविद्यालय ने इलेक्ट्रॉनिक स्थानीय समाचार पत्रों की सदस्यता बनाए रखी है।',
            category: 'Viral',
        },
        {
            id: '35',
            name: 'Viral',
            url: 'https://uonlibrary.uonbi.ac.ke/sites/uonlibrary.uonbi.ac.ke/files/styles/large/public/2022-02/e-paper.jpeg?itok=pDd6FcRT',
            heading: 'मानक और राष्ट्र ई- समाचार पत्र कैसे प्राप्त करें',
            discription: 'वर्तमान जागरूकता सूचना तक पहुंच बढ़ाने के लिए विश्वविद्यालय ने इलेक्ट्रॉनिक स्थानीय समाचार पत्रों की सदस्यता बनाए रखी है।',
            category: 'Viral',
        },
        {
            id: '36',
            name: 'Viral',
            url: 'https://uonlibrary.uonbi.ac.ke/sites/uonlibrary.uonbi.ac.ke/files/styles/large/public/2022-02/e-paper.jpeg?itok=pDd6FcRT',
            heading: 'मानक और राष्ट्र ई- समाचार पत्र कैसे प्राप्त करें',
            discription: 'वर्तमान जागरूकता सूचना तक पहुंच बढ़ाने के लिए विश्वविद्यालय ने इलेक्ट्रॉनिक स्थानीय समाचार पत्रों की सदस्यता बनाए रखी है।',
            category: 'Viral',
        },
        {
            id: '37',
            name: 'मूवी',
            url: 'https://uonlibrary.uonbi.ac.ke/sites/uonlibrary.uonbi.ac.ke/files/styles/large/public/2022-02/e-paper.jpeg?itok=pDd6FcRT',
            heading: 'मानक और राष्ट्र ई- समाचार पत्र कैसे प्राप्त करें',
            discription: 'वर्तमान जागरूकता सूचना तक पहुंच बढ़ाने के लिए विश्वविद्यालय ने इलेक्ट्रॉनिक स्थानीय समाचार पत्रों की सदस्यता बनाए रखी है।',
            category: 'मूवी',
        },
        {
            id: '38',
            name: 'मूवी',
            url: 'https://uonlibrary.uonbi.ac.ke/sites/uonlibrary.uonbi.ac.ke/files/styles/large/public/2022-02/e-paper.jpeg?itok=pDd6FcRT',
            heading: 'मानक और राष्ट्र ई- समाचार पत्र कैसे प्राप्त करें',
            discription: 'वर्तमान जागरूकता सूचना तक पहुंच बढ़ाने के लिए विश्वविद्यालय ने इलेक्ट्रॉनिक स्थानीय समाचार पत्रों की सदस्यता बनाए रखी है।',
            category: 'मूवी',
        },
        {
            id: '39',
            name: 'मूवी',
            url: 'https://uonlibrary.uonbi.ac.ke/sites/uonlibrary.uonbi.ac.ke/files/styles/large/public/2022-02/e-paper.jpeg?itok=pDd6FcRT',
            heading: 'मानक और राष्ट्र ई- समाचार पत्र कैसे प्राप्त करें',
            discription: 'वर्तमान जागरूकता सूचना तक पहुंच बढ़ाने के लिए विश्वविद्यालय ने इलेक्ट्रॉनिक स्थानीय समाचार पत्रों की सदस्यता बनाए रखी है।',
            category: 'मूवी',
        },
        {
            id: '40',
            name: 'लाइफस्टाइल',
            url: 'https://uonlibrary.uonbi.ac.ke/sites/uonlibrary.uonbi.ac.ke/files/styles/large/public/2022-02/e-paper.jpeg?itok=pDd6FcRT',
            heading: 'मानक और राष्ट्र ई- समाचार पत्र कैसे प्राप्त करें',
            discription: 'वर्तमान जागरूकता सूचना तक पहुंच बढ़ाने के लिए विश्वविद्यालय ने इलेक्ट्रॉनिक स्थानीय समाचार पत्रों की सदस्यता बनाए रखी है।',
            category: 'लाइफस्टाइल',
        },
        {
            id: '41',
            name: 'लाइफस्टाइल',
            url: 'https://uonlibrary.uonbi.ac.ke/sites/uonlibrary.uonbi.ac.ke/files/styles/large/public/2022-02/e-paper.jpeg?itok=pDd6FcRT',
            heading: 'मानक और राष्ट्र ई- समाचार पत्र कैसे प्राप्त करें',
            discription: 'वर्तमान जागरूकता सूचना तक पहुंच बढ़ाने के लिए विश्वविद्यालय ने इलेक्ट्रॉनिक स्थानीय समाचार पत्रों की सदस्यता बनाए रखी है।',
            category: 'लाइफस्टाइल',
        },
        {
            id: '42',
            name: 'लाइफस्टाइल',
            url: 'https://uonlibrary.uonbi.ac.ke/sites/uonlibrary.uonbi.ac.ke/files/styles/large/public/2022-02/e-paper.jpeg?itok=pDd6FcRT',
            heading: 'मानक और राष्ट्र ई- समाचार पत्र कैसे प्राप्त करें',
            discription: 'वर्तमान जागरूकता सूचना तक पहुंच बढ़ाने के लिए विश्वविद्यालय ने इलेक्ट्रॉनिक स्थानीय समाचार पत्रों की सदस्यता बनाए रखी है।',
            category: 'लाइफस्टाइल',
        },
        {
            id: '43',
            name: 'दुनिया',
            url: 'https://uonlibrary.uonbi.ac.ke/sites/uonlibrary.uonbi.ac.ke/files/styles/large/public/2022-02/e-paper.jpeg?itok=pDd6FcRT',
            heading: 'मानक और राष्ट्र ई- समाचार पत्र कैसे प्राप्त करें',
            discription: 'वर्तमान जागरूकता सूचना तक पहुंच बढ़ाने के लिए विश्वविद्यालय ने इलेक्ट्रॉनिक स्थानीय समाचार पत्रों की सदस्यता बनाए रखी है।',
            category: 'दुनिया',
        },
        {
            id: '44',
            name: 'दुनिया',
            url: 'https://uonlibrary.uonbi.ac.ke/sites/uonlibrary.uonbi.ac.ke/files/styles/large/public/2022-02/e-paper.jpeg?itok=pDd6FcRT',
            heading: 'मानक और राष्ट्र ई- समाचार पत्र कैसे प्राप्त करें',
            discription: 'वर्तमान जागरूकता सूचना तक पहुंच बढ़ाने के लिए विश्वविद्यालय ने इलेक्ट्रॉनिक स्थानीय समाचार पत्रों की सदस्यता बनाए रखी है।',
            category: 'दुनिया',
        },
        {
            id: '45',
            name: 'दुनिया',
            url: 'https://uonlibrary.uonbi.ac.ke/sites/uonlibrary.uonbi.ac.ke/files/styles/large/public/2022-02/e-paper.jpeg?itok=pDd6FcRT',
            heading: 'मानक और राष्ट्र ई- समाचार पत्र कैसे प्राप्त करें',
            discription: 'वर्तमान जागरूकता सूचना तक पहुंच बढ़ाने के लिए विश्वविद्यालय ने इलेक्ट्रॉनिक स्थानीय समाचार पत्रों की सदस्यता बनाए रखी है।',
            category: 'दुनिया',
        },
        {
            id: '46',
            name: 'ऑटो',
            url: 'https://uonlibrary.uonbi.ac.ke/sites/uonlibrary.uonbi.ac.ke/files/styles/large/public/2022-02/e-paper.jpeg?itok=pDd6FcRT',
            heading: 'मानक और राष्ट्र ई- समाचार पत्र कैसे प्राप्त करें',
            discription: 'वर्तमान जागरूकता सूचना तक पहुंच बढ़ाने के लिए विश्वविद्यालय ने इलेक्ट्रॉनिक स्थानीय समाचार पत्रों की सदस्यता बनाए रखी है।',
            category: 'ऑटो',
        },
        {
            id: '47',
            name: 'ऑटो',
            url: 'https://uonlibrary.uonbi.ac.ke/sites/uonlibrary.uonbi.ac.ke/files/styles/large/public/2022-02/e-paper.jpeg?itok=pDd6FcRT',
            heading: 'मानक और राष्ट्र ई- समाचार पत्र कैसे प्राप्त करें',
            discription: 'वर्तमान जागरूकता सूचना तक पहुंच बढ़ाने के लिए विश्वविद्यालय ने इलेक्ट्रॉनिक स्थानीय समाचार पत्रों की सदस्यता बनाए रखी है।',
            category: 'ऑटो',
        },
        {
            id: '48',
            name: 'ऑटो',
            url: 'https://uonlibrary.uonbi.ac.ke/sites/uonlibrary.uonbi.ac.ke/files/styles/large/public/2022-02/e-paper.jpeg?itok=pDd6FcRT',
            heading: 'मानक और राष्ट्र ई- समाचार पत्र कैसे प्राप्त करें',
            discription: 'वर्तमान जागरूकता सूचना तक पहुंच बढ़ाने के लिए विश्वविद्यालय ने इलेक्ट्रॉनिक स्थानीय समाचार पत्रों की सदस्यता बनाए रखी है।',
            category: 'ऑटो',
        },
        {
            id: '49',
            name: 'टेक',
            url: 'https://uonlibrary.uonbi.ac.ke/sites/uonlibrary.uonbi.ac.ke/files/styles/large/public/2022-02/e-paper.jpeg?itok=pDd6FcRT',
            heading: 'मानक और राष्ट्र ई- समाचार पत्र कैसे प्राप्त करें',
            discription: 'वर्तमान जागरूकता सूचना तक पहुंच बढ़ाने के लिए विश्वविद्यालय ने इलेक्ट्रॉनिक स्थानीय समाचार पत्रों की सदस्यता बनाए रखी है।',
            category: 'टेक',
        },
        {
            id: '50',
            name: 'टेक',
            url: 'https://uonlibrary.uonbi.ac.ke/sites/uonlibrary.uonbi.ac.ke/files/styles/large/public/2022-02/e-paper.jpeg?itok=pDd6FcRT',
            heading: 'मानक और राष्ट्र ई- समाचार पत्र कैसे प्राप्त करें',
            discription: 'वर्तमान जागरूकता सूचना तक पहुंच बढ़ाने के लिए विश्वविद्यालय ने इलेक्ट्रॉनिक स्थानीय समाचार पत्रों की सदस्यता बनाए रखी है।',
            category: 'टेक',
        },
        {
            id: '51',
            name: 'टेक',
            url: 'https://uonlibrary.uonbi.ac.ke/sites/uonlibrary.uonbi.ac.ke/files/styles/large/public/2022-02/e-paper.jpeg?itok=pDd6FcRT',
            heading: 'मानक और राष्ट्र ई- समाचार पत्र कैसे प्राप्त करें',
            discription: 'वर्तमान जागरूकता सूचना तक पहुंच बढ़ाने के लिए विश्वविद्यालय ने इलेक्ट्रॉनिक स्थानीय समाचार पत्रों की सदस्यता बनाए रखी है।',
            category: 'टेक',
        },
        {
            id: '52',
            name: 'एजुकेशन',
            url: 'https://uonlibrary.uonbi.ac.ke/sites/uonlibrary.uonbi.ac.ke/files/styles/large/public/2022-02/e-paper.jpeg?itok=pDd6FcRT',
            heading: 'मानक और राष्ट्र ई- समाचार पत्र कैसे प्राप्त करें',
            discription: 'वर्तमान जागरूकता सूचना तक पहुंच बढ़ाने के लिए विश्वविद्यालय ने इलेक्ट्रॉनिक स्थानीय समाचार पत्रों की सदस्यता बनाए रखी है।',
            category: 'एजुकेशन',
        },
        {
            id: '53',
            name: 'एजुकेशन',
            url: 'https://uonlibrary.uonbi.ac.ke/sites/uonlibrary.uonbi.ac.ke/files/styles/large/public/2022-02/e-paper.jpeg?itok=pDd6FcRT',
            heading: 'मानक और राष्ट्र ई- समाचार पत्र कैसे प्राप्त करें',
            discription: 'वर्तमान जागरूकता सूचना तक पहुंच बढ़ाने के लिए विश्वविद्यालय ने इलेक्ट्रॉनिक स्थानीय समाचार पत्रों की सदस्यता बनाए रखी है।',
            category: 'एजुकेशन',
        },
        {
            id: '54',
            name: 'एजुकेशन',
            url: 'https://uonlibrary.uonbi.ac.ke/sites/uonlibrary.uonbi.ac.ke/files/styles/large/public/2022-02/e-paper.jpeg?itok=pDd6FcRT',
            heading: 'मानक और राष्ट्र ई- समाचार पत्र कैसे प्राप्त करें',
            discription: 'वर्तमान जागरूकता सूचना तक पहुंच बढ़ाने के लिए विश्वविद्यालय ने इलेक्ट्रॉनिक स्थानीय समाचार पत्रों की सदस्यता बनाए रखी है।',
            category: 'एजुकेशन',
        },
        {
            id: '52',
            name: 'और',
            url: 'https://uonlibrary.uonbi.ac.ke/sites/uonlibrary.uonbi.ac.ke/files/styles/large/public/2022-02/e-paper.jpeg?itok=pDd6FcRT',
            heading: 'मानक और राष्ट्र ई- समाचार पत्र कैसे प्राप्त करें',
            discription: 'वर्तमान जागरूकता सूचना तक पहुंच बढ़ाने के लिए विश्वविद्यालय ने इलेक्ट्रॉनिक स्थानीय समाचार पत्रों की सदस्यता बनाए रखी है।',
            category: 'और',
        },
    ])
    const [currentnews, setCurrentNews] = useState({})

    const [clickedId, setClickedId] = useState('सभी')
    const onPressButton = () => {

    }
    return (
        <SafeAreaView style={styles.container}>
            <StatusBar backgroundColor={Customcolor.lightwhite} barStyle={'dark-content'} />
            <ScrollView>

                <View style={styles.navbarheader}>
                    <View style={{ flex: 0.7, flexDirection: 'row', alignItems: 'center' }}>
                        <TouchableOpacity onPress={() => {
                            // navigation.navigate('Home')
                            navigation.openDrawer()
                        }} style={styles.Imageline}>

                            <Image style={{ width: horizScale(23), height: vertScale(20), }}
                                source={require('../../Asset/images/drawer.png')} />
                        </TouchableOpacity>

                        <View style={{ flex: 0.7, justifyContent: 'flex-start' }}>
                            <Image style={{ width: horizScale(100), height: vertScale(30) }}
                                source={require('../../Asset/images/navbharat-times.webp')} />
                        </View>
                    </View>
                    <View style={{
                        flex: 0.3, flexDirection: 'row', justifyContent: 'flex-start',
                        alignItems: 'center'
                    }}>
                        <TouchableOpacity onPress={() => {
                            navigation.navigate('search')
                        }}
                            style={{
                                flex: 0.3, backgroundColor: Customcolor.white,
                                justifyContent: 'center',
                                alignItems: 'center',
                                borderRadius: horizScale(100),
                                padding: horizScale(10),
                            }}>
                            <Image style={styles.Imagesearch}
                                source={require('../../Asset/images/search.png')}>
                            </Image>
                        </TouchableOpacity>

                        <TouchableOpacity onPress={() => {
                            alert('coming soon')
                        }} style={{
                            flex: 0.3,
                            justifyContent: 'center', borderRadius: horizScale(100),
                            padding: horizScale(10),
                            alignItems: 'center', backgroundColor: Customcolor.white, marginLeft: horizScale(15)
                        }}>
                            <Image style={styles.Imagebell}
                                source={require('../../Asset/images/bell.png')}>
                            </Image>
                        </TouchableOpacity>
                    </View>
                </View>
                <View style={{ marginVertical: horizScale(20) }}>
                    <FlatList
                        data={category}
                        contentContainerStyle={{ paddingHorizontal: horizScale(15) }}
                        ItemSeparatorComponent={() => (<View style={{ width: horizScale(15) }} />)}
                        renderItem={({ item }) => (
                            <TouchableOpacity
                                style={{
                                    justifyContent: 'center',
                                    alignItems: 'center',
                                    backgroundColor: clickedId == item ? Customcolor.skyblue : Customcolor.white,
                                    paddingVertical: horizScale(5),
                                    borderRadius: horizScale(50),
                                    paddingHorizontal: horizScale(20)

                                }} onPress={() => {
                                    setClickedId(item)
                                }}
                            >
                                <Text style={{
                                    color: 'white',
                                    fontWeight: 'bold',
                                    fontSize: fontSize.reqular,
                                    color: item == clickedId ? Customcolor.white : Customcolor.black,
                                }}>{item}
                                </Text>
                            </TouchableOpacity >)
                        }

                        horizontal={true}
                        // showsHorizontalScrollIndicator={false}
                        keyExtractor={(item) => item.id}
                    >
                    </FlatList>
                </View>

                <FlatList
                    data={news}
                    contentContainerStyle={{ paddingVertical: vertScale(20) }}
                    //ItemSeparatorComponent={() => (<View style={{ height: horizScale(25) }} />)}
                    renderItem={({ item }) => {
                        if (clickedId === item.category || clickedId == 'सभी') {
                            return (
                                <TouchableOpacity
                                    activeOpacity={0.8}
                                    onPress={() => {
                                        navigation.navigate('detailed', { news: item })
                                    }}
                                    style={styles.newsContainer}
                                >


                                    <View style={{ flex: 0.33 }}>

                                        <Image style={styles.images}
                                            source={{ uri: item.url }}></Image>

                                    </View>
                                    <View style={{
                                        flex: 0.67, backgroundColor: Customcolor.white, marginLeft: horizScale(10),
                                        borderRadius: 10,
                                    }}>
                                        <Text style={styles.overlytext}>{item.heading}</Text>
                                    </View>

                                </TouchableOpacity>
                            )
                        }
                        else {
                            return <View />
                        }

                    }}
                    keyExtractor={(item) => item.id}
                />
            </ScrollView>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    newsContainer: {
        flexDirection: 'row',
        backgroundColor: Customcolor.white,
        paddingVertical: horizScale(15),
        marginHorizontal: horizScale(15),
        borderRadius: horizScale(15),
        marginTop: horizScale(15),
        elevation: 5
    },
    container: {
        flex: 1,
        backgroundColor: Customcolor.lightwhite,

    },
    Imageline: {
        flex: 0.15,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: horizScale(100),
        padding: horizScale(10),
        backgroundColor: Customcolor.white,
        marginHorizontal: horizScale(15)
    },

    Imagesearch: {
        width: horizScale(20),
        height: vertScale(20),
        //marginLeft: horizScale(115)
    },
    Imagebell: {
        width: horizScale(20),
        height: vertScale(20),
        //marginLeft: horizScale(110)
    },

    images: {
        width: '90%',
        height: vertScale(90),
        resizeMode: "cover",
        borderRadius: horizScale(5),
        alignSelf: 'center'
    },
    overlytext: {
        color: Customcolor.black,
        fontSize: fontSize.medium,
        fontWeight: "700",
    },
    navbarheader: {
        width: '100%',

        alignSelf: 'center',
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: Customcolor.lightwhite,
        paddingVertical: horizScale(15),
        elevation: 1
    }

})

export default HomeScreentab;