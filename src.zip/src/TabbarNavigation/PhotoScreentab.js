import React, { useState } from 'react';
import {
    View, Text, FlatList,
    StyleSheet,
    ScrollView,
    SafeAreaView,
    Image,
    ImageBackground,
    TouchableOpacity,
    Button,

} from 'react-native';
import {
    Card,
    Title,
} from 'react-native-paper'
import { Customcolor } from '../Utility/Customcolor';
import { Customimage } from '../Utility/Customimage';
import { fontSize } from '../Utility/Fontsize';
import { horizScale, Layout, vertScale } from '../Utility/Layout';


const MycityScreentab = ({ navigation }) => {
    const [selectednews, setselectednews] = useState();

    const [citynews, setCityNews] = useState([
        {
            id: '1',
            images: 'https://static.langimg.com/thumb/msid-92516973,imgsize-59446,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'CM गहलोत के पट्टा अभियान की ऐसे हो रही फजीहत! भूमाफियाओं के डर से दिव्यांग रिटायर्ड फौजी जमीन रजिस्ट्री के लिए भटक रहा दर दर'
        },
        {
            id: '2',
            images: 'https://static.langimg.com/thumb/msid-92495429,imgsize-66084,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'CUET 2022: इन प्वाइंस की मदद से करें यूनिवर्सिटी एंट्रेंस की तैयारी, मिलेगी सफलता'
        },
        {
            id: '3',
            images: 'https://static.langimg.com/thumb/msid-90585751,imgsize-27796,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'CUET 2022: कॉमन यूनिवर्सिटी एंट्रेंस टेस्ट के लिए कल से शुरू होंगे रजिस्ट्रेशन, ऐसे कर पाएंगे अप्लाई'
        },
        {
            id: '4',
            images: 'https://static.langimg.com/thumb/msid-90635532,imgsize-56428,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'CUET 2022 Registration: सीयूईटी के लिए 6 अप्रैल से शुरू होंगे रजिस्ट्रेशन, तैयार रखें ये डॉक्यूमेंट्स'
        },
        {
            id: '5',
            images: 'https://static.langimg.com/thumb/msid-92516973,imgsize-59446,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'CM गहलोत के पट्टा अभियान की ऐसे हो रही फजीहत! भूमाफियाओं के डर से दिव्यांग रिटायर्ड फौजी जमीन रजिस्ट्री के लिए भटक रहा दर दर'
        }
    ])
    const [currentnews, setCurrentNews] = useState({})

    const [clickedId, setClickedId] = useState('Home')
    const onPressButton = () => {

    }
    return (
        <SafeAreaView style={styles.container}>
            <ScrollView>

                <View style={{
                    width: '100%', alignSelf: 'center', flexDirection: 'row',
                    alignItems: 'center', top: vertScale(20)
                }}>
                    <View style={{ flex: 0.5, flexDirection: 'row', }}>
                        <TouchableOpacity onPress={() => {
                            navigation.navigate('homedrawer')
                        }} style={styles.Imageline}>

                            <Image style={{ width: horizScale(23), height: vertScale(20), marginLeft: horizScale(20), marginTop: vertScale(5) }}
                                source={require('../../Asset/images/drawer.png')} />
                        </TouchableOpacity>

                        <View style={{ flex: 0.4, }}>
                            <Image style={{ width: horizScale(100), height: vertScale(30), marginLeft: horizScale(50) }}
                                source={require('../../Asset/images/navbharat-times.webp')} />
                        </View>
                    </View>
                    <View style={{ flex: 0.5, flexDirection: 'row' }}>
                        <TouchableOpacity onPress={() => {
                            navigation.navigate('search')
                        }} style={{ flex: 0.2 }}>
                            <Image style={styles.Imagesearch}
                                source={require('../../Asset/images/search.png')}>
                            </Image>
                        </TouchableOpacity>

                        <TouchableOpacity onPress={() => {
                            alert('coming soon')
                        }} style={{ flex: 0.2 }}>
                            <Image style={styles.Imagebell}
                                source={require('../../Asset/images/bell.png')}>
                            </Image>
                        </TouchableOpacity>
                    </View>
                </View>



                <View style={{
                    flex: 1, backgroundColor: Customcolor.lightwhite,
                    marginTop: 40, elevation: 4, padding: 10
                }}>
                    <View style={{ flex: 1, flexDirection: 'row' }}>
                        <View style={{ flex: 2 }}>
                            <Text style={{
                                color: Customcolor.black, fontSize: fontSize.h6,
                                marginLeft: 20, marginTop: vertScale(20), alignSelf: 'flex-start',
                                fontWeight: '600'
                            }}>{'ट्रैवल'}</Text>
                        </View>
                        <View style={{ flex: 4 }}>
                            <Text style={{
                                color: Customcolor.black, fontSize: fontSize.h6,
                                marginLeft: 20, marginTop: vertScale(20), alignSelf: 'flex-end',
                                fontWeight: '400'
                            }}>{'और देखें'}</Text>
                        </View>
                        <View style={{ flex: 1 }}>
                            <Image style={{
                                width: horizScale(16), height: vertScale(16),
                                marginLeft: 20, marginTop: vertScale(25), alignSelf: 'flex-start'
                            }}
                                source={require('../../Asset/images/nest.png')} />
                        </View>

                    </View>
                    <FlatList
                        data={citynews}
                        // ItemSeparatorComponent={() => (<View style={{ width: horizScale(5) }} />)}

                        renderItem={({ item }) => {
                            if (clickedId == item.category || clickedId == 'Home')
                                return (

                                    <TouchableOpacity
                                        activeOpacity={0.8}
                                        onPress={() => {
                                            navigation.navigate('detailed', { news: item })
                                        }}
                                        style={styles.flatlistContainer}
                                    >
                                        <Image style={{
                                            width: horizScale(220), height: vertScale(160),
                                        }}
                                            source={{ uri: item.images }} />
                                        <Text style={styles.flatlistheading}>
                                            {item.heading}</Text>

                                    </TouchableOpacity>
                                )
                        }}
                        keyExtractor={(item) => item.id}
                        horizontal
                    />



                    <View style={{ flex: 1, flexDirection: 'row' }}>
                        <View style={{ flex: 2 }}>
                            <Text style={{
                                color: Customcolor.black, fontSize: fontSize.h6,
                                marginLeft: 20, marginTop: vertScale(20), alignSelf: 'flex-start',
                                fontWeight: '600'
                            }}>{'स्पोर्ट्स'}</Text>
                        </View>
                        <View style={{ flex: 4 }}>
                            <Text style={{
                                color: Customcolor.black, fontSize: fontSize.h6,
                                marginLeft: 20, marginTop: vertScale(20), alignSelf: 'flex-end',
                                fontWeight: '400'
                            }}>{'और देखें'}</Text>
                        </View>
                        <View style={{ flex: 1 }}>
                            <Image style={{
                                width: horizScale(16), height: vertScale(16),
                                marginLeft: 20, marginTop: vertScale(25), alignSelf: 'flex-start'
                            }}
                                source={require('../../Asset/images/nest.png')} />
                        </View>

                    </View>
                    <FlatList
                        data={citynews}
                        // ItemSeparatorComponent={() => (<View style={{ width: horizScale(5) }} />)}

                        renderItem={({ item }) => {
                            if (clickedId == item.category || clickedId == 'Home')
                                return (

                                    <TouchableOpacity
                                        activeOpacity={0.8}
                                        onPress={() => {
                                            navigation.navigate('detailed', { news: item })
                                        }}
                                        style={styles.flatlistContainer}
                                    >
                                        <Image style={{
                                            width: horizScale(220), height: vertScale(160),
                                        }}
                                            source={{ uri: item.images }} />
                                        <Text style={styles.flatlistheading}>
                                            {item.heading}</Text>

                                    </TouchableOpacity>
                                )
                        }}
                        keyExtractor={(item) => item.id}
                        horizontal
                    />

                    <View style={{ flex: 1, flexDirection: 'row' }}>
                        <View style={{ flex: 3 }}>
                            <Text style={{
                                color: Customcolor.black, fontSize: fontSize.h6,
                                marginLeft: 20, marginTop: vertScale(20), alignSelf: 'flex-start',
                                fontWeight: '600',
                            }}>{'लाइफस्टाइल'}</Text>
                        </View>
                        <View style={{ flex: 4 }}>
                            <Text style={{
                                color: Customcolor.black, fontSize: fontSize.h6,
                                marginLeft: 20, marginTop: vertScale(20), alignSelf: 'flex-end',
                                fontWeight: '400'
                            }}>{'और देखें'}</Text>
                        </View>
                        <View style={{ flex: 1 }}>
                            <Image style={{
                                width: horizScale(16), height: vertScale(16),
                                marginLeft: 20, marginTop: vertScale(25), alignSelf: 'flex-start'
                            }}
                                source={require('../../Asset/images/nest.png')} />
                        </View>

                    </View>
                    <FlatList
                        data={citynews}
                        // ItemSeparatorComponent={() => (<View style={{ width: horizScale(5) }} />)}

                        renderItem={({ item }) => {
                            if (clickedId == item.category || clickedId == 'Home')
                                return (

                                    <TouchableOpacity
                                        activeOpacity={0.8}
                                        onPress={() => {
                                            navigation.navigate('detailed', { news: item })
                                        }}
                                        style={styles.flatlistContainer}
                                    >
                                        <Image style={{
                                            width: horizScale(220), height: vertScale(160),
                                        }}
                                            source={{ uri: item.images }} />
                                        <Text style={styles.flatlistheading}>
                                            {item.heading}</Text>

                                    </TouchableOpacity>
                                )
                        }}
                        keyExtractor={(item) => item.id}
                        horizontal
                    />

                    <View style={{ flex: 1, flexDirection: 'row' }}>
                        <View style={{ flex: 2 }}>
                            <Text style={{
                                color: Customcolor.black, fontSize: fontSize.h6,
                                marginLeft: 20, marginTop: vertScale(20), alignSelf: 'flex-start',
                                fontWeight: '600'
                            }}>{'टेक'}</Text>
                        </View>
                        <View style={{ flex: 4 }}>
                            <Text style={{
                                color: Customcolor.black, fontSize: fontSize.h6,
                                marginLeft: 20, marginTop: vertScale(20), alignSelf: 'flex-end',
                                fontWeight: '400'
                            }}>{'और देखें'}</Text>
                        </View>
                        <View style={{ flex: 1 }}>
                            <Image style={{
                                width: horizScale(16), height: vertScale(16),
                                marginLeft: 20, marginTop: vertScale(25), alignSelf: 'flex-start'
                            }}
                                source={require('../../Asset/images/nest.png')} />
                        </View>

                    </View>
                    <FlatList
                        data={citynews}
                        // ItemSeparatorComponent={() => (<View style={{ width: horizScale(5) }} />)}

                        renderItem={({ item }) => {
                            if (clickedId == item.category || clickedId == 'Home')
                                return (

                                    <TouchableOpacity
                                        activeOpacity={0.8}
                                        onPress={() => {
                                            navigation.navigate('detailed', { news: item })
                                        }}
                                        style={styles.flatlistContainer}
                                    >
                                        <Image style={{
                                            width: horizScale(220), height: vertScale(160),
                                        }}
                                            source={{ uri: item.images }} />
                                        <Text style={styles.flatlistheading}>
                                            {item.heading}</Text>

                                    </TouchableOpacity>
                                )
                        }}
                        keyExtractor={(item) => item.id}
                        horizontal
                    />

                    <View style={{ flex: 1, flexDirection: 'row' }}>
                        <View style={{ flex: 2 }}>
                            <Text style={{
                                color: Customcolor.black, fontSize: fontSize.h6,
                                marginLeft: 20, marginTop: vertScale(20), alignSelf: 'flex-start',
                                fontWeight: '600'
                            }}>{'ऑटो'}</Text>
                        </View>
                        <View style={{ flex: 4 }}>
                            <Text style={{
                                color: Customcolor.black, fontSize: fontSize.h6,
                                marginLeft: 20, marginTop: vertScale(20), alignSelf: 'flex-end',
                                fontWeight: '400'
                            }}>{'और देखें'}</Text>
                        </View>
                        <View style={{ flex: 1 }}>
                            <Image style={{
                                width: horizScale(16), height: vertScale(16),
                                marginLeft: 20, marginTop: vertScale(25), alignSelf: 'flex-start'
                            }}
                                source={require('../../Asset/images/nest.png')} />
                        </View>

                    </View>
                    <FlatList
                        data={citynews}
                        // ItemSeparatorComponent={() => (<View style={{ width: horizScale(5) }} />)}

                        renderItem={({ item }) => {
                            if (clickedId == item.category || clickedId == 'Home')
                                return (

                                    <TouchableOpacity
                                        activeOpacity={0.8}
                                        onPress={() => {
                                            navigation.navigate('detailed', { news: item })
                                        }}
                                        style={styles.flatlistContainer}
                                    >
                                        <Image style={{
                                            width: horizScale(220), height: vertScale(160),
                                        }}
                                            source={{ uri: item.images }} />
                                        <Text style={styles.flatlistheading}>
                                            {item.heading}</Text>

                                    </TouchableOpacity>
                                )
                        }}
                        keyExtractor={(item) => item.id}
                        horizontal
                    />


                    <View style={{ flex: 1, flexDirection: 'row' }}>
                        <View style={{ flex: 2 }}>
                            <Text style={{
                                color: Customcolor.black, fontSize: fontSize.h6,
                                marginLeft: 20, marginTop: vertScale(20), alignSelf: 'flex-start',
                                fontWeight: '600'
                            }}>{'बिजनेस'}</Text>
                        </View>
                        <View style={{ flex: 4 }}>
                            <Text style={{
                                color: Customcolor.black, fontSize: fontSize.h6,
                                marginLeft: 20, marginTop: vertScale(20), alignSelf: 'flex-end',
                                fontWeight: '400'
                            }}>{'और देखें'}</Text>
                        </View>
                        <View style={{ flex: 1 }}>
                            <Image style={{
                                width: horizScale(16), height: vertScale(16),
                                marginLeft: 20, marginTop: vertScale(25), alignSelf: 'flex-start'
                            }}
                                source={require('../../Asset/images/nest.png')} />
                        </View>

                    </View>
                    <FlatList
                        data={citynews}
                        // ItemSeparatorComponent={() => (<View style={{ width: horizScale(5) }} />)}

                        renderItem={({ item }) => {
                            if (clickedId == item.category || clickedId == 'Home')
                                return (

                                    <TouchableOpacity
                                        activeOpacity={0.8}
                                        onPress={() => {
                                            navigation.navigate('detailed', { news: item })
                                        }}
                                        style={styles.flatlistContainer}
                                    >
                                        <Image style={{
                                            width: horizScale(220), height: vertScale(160),
                                        }}
                                            source={{ uri: item.images }} />
                                        <Text style={styles.flatlistheading}>
                                            {item.heading}</Text>

                                    </TouchableOpacity>
                                )
                        }}
                        keyExtractor={(item) => item.id}
                        horizontal
                    />
                </View>
            </ScrollView>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    flatlistContainer: {
        backgroundColor: Customcolor.white,
        paddingVertical: horizScale(10),
        marginHorizontal: horizScale(10),
        borderRadius: horizScale(8),
        elevation: 5,
        marginTop: 5,
        // justifyContent: 'center',
        // alignItems: 'center'
    },

    container: {
        flex: 1,
        backgroundColor: Customcolor.white,

    },
    Imageline: {
        flex: 0.1,
        width: horizScale(30),
        height: vertScale(30),
    },

    Imagesearch: {
        width: horizScale(20),
        height: vertScale(20),
        marginLeft: horizScale(115)
    },
    Imagebell: {
        width: horizScale(20),
        height: vertScale(20),
        marginLeft: horizScale(110)
    },

    images: {
        width: '90%',
        height: vertScale(90),
        resizeMode: "cover",
        borderRadius: horizScale(5),
        alignSelf: 'center'
    },
    overlytext: {
        color: Customcolor.black,
        fontSize: fontSize.medium,
        fontWeight: "700",
    },
    flatlistheading: {
        width: horizScale(200),
        height: vertScale(50),
        color: Customcolor.black,
        marginLeft: horizScale(10),
        marginTop: vertScale(10)
    }

})

export default MycityScreentab;