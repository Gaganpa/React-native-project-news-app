// import {
//     StyleSheet,
//     Text,
//     View,
//     TouchableOpacity,
//     FlatList,
//     SafeAreaView,
//     StatusBar,
// } from 'react-native';
// import React, { useState } from 'react';
// import { horizScale, vertScale } from '../Utility/Layout';
// import { fontSize } from '../Utility/Fontsize';
// import VideoPlayer from 'react-native-video-player'

// export default function VedioScreentab(props) {
//     const [data, setData] = useState([
//         {
//             id: 1,
//             vid: 'https://www.w3schools.com/html/mov_bbb.mp4',
//             isPause: false,
//         },
//         {
//             id: 2,
//             vid: 'https://www.w3schools.com/html/mov_bbb.mp4',
//             isPause: false,
//         },
//         {
//             id: 3,
//             vid: 'https://www.w3schools.com/html/mov_bbb.mp4',
//             isPause: false,
//         },
//         {
//             id: 4,
//             vid: 'https://www.w3schools.com/html/mov_bbb.mp4',
//             isPause: false,
//         },
//         {
//             id: 5,
//             vid: 'https://www.w3schools.com/html/mov_bbb.mp4',
//             isPause: false,
//         },
//         {
//             id: 6,
//             vid: 'https://www.w3schools.com/html/mov_bbb.mp4',
//             isPause: false,
//         },
//     ]);

//     return (
//         <SafeAreaView style={styles.container}>
//             <StatusBar backgroundColor='green' barStyle="dark-content" />
//             <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
//                 <Text
//                     style={{
//                         margin: 10,
//                         fontWeight: 'bold',
//                         color: 'red',
//                         fontSize: fontSize.reqular,
//                     }}>
//                     Watch in your language
//                 </Text>
//                 <TouchableOpacity
//                     onPress={() => {
//                         navigation.navigate('more', { list: images });
//                     }}>
//                     <Text
//                         style={{
//                             margin: 10,
//                             color: 'green',
//                             fontSize: fontSize.reqular,
//                             fontWeight: 'bold',
//                         }}>
//                         {/* more... */}
//                     </Text>
//                 </TouchableOpacity>
//             </View>
//             <FlatList
//                 contentContainerStyle={{
//                     backgroundColor: 'red',
//                     height: 170,
//                 }}
//                 data={data}
//                 horizontal
//                 showsHorizontalScrollIndicator={false}
//                 renderItem={({ item, index }) => {
//                     return (
//                         <View
//                             style={{
//                                 flexDirection: 'row',

//                                 backgroundColor: 'red',
//                                 marginVertical: 10,
//                                 paddingVertical: 20,
//                                 marginHorizontal: 10,

//                                 borderRadius: 10,
//                                 height: 150,
//                                 width: 200,

//                                 borderRadius: 10,
//                             }}>
//                             <VideoPlayer
//                                 style={styles.video}
//                                 source={{ uri: item.vid }}
//                                 useNativeControls
//                                 resizeMode="cover"
//                                 isLooping={true}
//                             />
//                         </View>
//                     );
//                 }}
//             />
//         </SafeAreaView>
//     );
// }

// const styles = StyleSheet.create({
//     video: {
//         width: '95%',
//         position: 'absolute',
//         top: 0,
//         left: 0,
//         bottom: 0,
//         right: 0,
//         backgroundColor: 'black',
//     },

//     backgroundVideo: {
//         height: 250,
//         width: '100%',
//     },

//     container: {
//         flex: 1,

//         backgroundColor: 'white',
//     },
// });


import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const VedioScreentab = () => {
    return (
        <View>
            <Text>VedioScreentab</Text>
        </View>
    )
}

export default VedioScreentab

const styles = StyleSheet.create({})

