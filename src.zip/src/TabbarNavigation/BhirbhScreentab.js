import React, { useState } from 'react';
import {
    View, Text, FlatList,
    StyleSheet,
    ScrollView,
    SafeAreaView,
    Image,
    ImageBackground,
    TouchableOpacity,
    Button,
    Dimensions
} from 'react-native';
import { Customcolor } from '../Utility/Customcolor';
import { Customimage } from '../Utility/Customimage';
import { fontSize } from '../Utility/Fontsize';
import { horizScale, Layout, vertScale } from '../Utility/Layout';


const BhirbhScreentab = ({ navigation }) => {
    const [selectednews, setselectednews] = useState();

    const [category, setcategory] = useState([
        'सभी',
        'न्यूज',
        'खेल ब्रीफ',
        'मनोरंज',
        'लाइफस्टाइल',
        'टेक',
        'एजुकेशन-जॉब',
        'ऑटो',
    ])

    const [news, setnews] = useState([
        {
            id: '1',
            name: 'न्यूज',
            url: 'https://newsreach-publishers.s3.ap-south-1.amazonaws.com/asliazadi.com/2022/05/Samuh-Lagan-.jpeg',
            heading: 'धरमपुर के हथनबारी गांव में 25 आदिवासी जोडों के समूह लग्न में उपस्थित रहे संघ प्रदेश थ्रीडी भाजपा ओबीसी मोर्चा अध्यक्ष हरीश पटेल',
            discription: 'असली आजादी न्यूज नेटवर्क, धरमपुर 23 मई। गुजरात के धरमपुर तालुका के आंतरिक क्षेत्र में स्थित आदिवासी बहुल गांव हथनबारी में आज श्री कृष्ण परिवार और विश्व विख्यात कथाकार मेहुल जानी द्वारा 25 आदिवासी जोडों के लिए समूह लग्न का आयोजन किया गया था। गरीब आदिवासी परिवार की 25 बेटियां और 25 बेटे कथाकार मेहुल जानी का आशीर्वाद लेकर शादी के अटूट बंधन में बंध गये।',
            category: 'न्यूज',

        },
        {
            id: '2',
            name: 'खेल ब्रीफ',
            url: 'https://newsreach-publishers.s3.ap-south-1.amazonaws.com/asliazadi.com/2022/05/Amit-Shah-Book-1.jpg',
            heading: 'पीएम मोदी की प्रामाणिकता और पारदर्शिता पर विरोधी भी नहीं उठा सकते उंगली : शाह',
            discription: 'नई दिल्ली (ईएमएस)। उपराष्ट्रपति एम वेंकैया नायडू ने प्रधानमंत्री नरेन्द्र मोदी को एक ऐसा नेता बताया जिन्होंने दुनिया को यह दिखा दिया कि सपनों को कैसे साकार किया जा सकता है। उपराष्ट्रपति एम वेंकैया नायडु ने आज, 11 मई को नई दिल्ली में ‘मोदी @20: ड्रीम्स मीट डिलीवरी’ पुस्तक का विमोचन किया। इस अवसर पर विदेश मंत्री एस जयशंकर, कई केंद्रीय मंत्री, सांसद व वरिष्ठ नेता उपस्थित थे।',
            category: 'खेल ब्रीफ',

        },
        {
            id: '3',
            name: 'लाइफस्टाइल',
            url: 'https://newsreach-publishers.s3.ap-south-1.amazonaws.com/asliazadi.com/2022/03/Ashvini-praful-patel.jpeg',
            heading: 'केंद्रीय रेलवे, संचार एवं आईटी मंत्री अश्विनी वैष्णव से प्रशासक प्रफुल पटेल ने की मुलाकात',
            discription: '– प्रशासक प्रफुल पटेल ने संघ प्रदेश थ्रीडी के विकासलक्षी मुद्दों और आगामी प्रोजेक्टों पर की चर्चा असली आजादी न्यूज नेटवर्क, नई दिल्ली 05 मार्च। संघ प्रदेश दादरा एवं नगर हवेली और दमण- दीव तथा लक्षद्वीप के प्रशासक प्रफुल पटेल द्वारा नई दिल्ली में केंद्रीय मंत्रियों के साथ मुलाकात करने का सिलसिला जारी है। ',
            category: 'लाइफस्टाइल',

        },
        {
            id: '4',
            name: 'टेक',
            url: 'https://newsreach-publishers.s3.ap-south-1.amazonaws.com/asliazadi.com/2022/02/daman-diu-police-2.jpg',
            heading: 'संघ प्रदेश दादरा नगर हवेली और दमण-दीव पुलिस विभाग के 2 आईपीएस एसपी अमित शर्मा और अनुज कुमार को मिला पुलिस वीरता पुरस्कार',
            discription: '– दिल्ली में सीएए और एनआरसी के खिलाफ दंगों को रोकने वाले – दिल्ली पुलिस के 75वें स्थापना दिवस पर आयोजित समारोह में गृहमंत्री अमित शाह ने दमण एसपी अमित शर्मा और दीव एसपी अनुज कुमार को किया सम्मानित असली आजादी न्यूज नेटवर्क, नई दिल्ली/ दमण / दीव 16 फरवरी। ',
            category: 'टेक',

        },
        {
            id: '5',
            name: 'एजुकेशन-जॉब',
            url: 'https://static.langimg.com/thumb/msid-92541998,imgsize-51298,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'Bihar Politics: बिहार में ओवैसी का पत्ता साफ, 5 में से चार विधायकों ने थाम ली लालटेन',
            discription: '– पटना: बिहार में विधानसभा के मॉनसून सत्र के दौरान AIMIM चीफ असदुद्दीन ओवैसी पर सियासी बिजली गिर गई है। उनके 5 में से चार विधायकों ने लालू यादव की पार्टी आरजेडी का दामन थाम लिया है। पीएम मोदी के खिलाफ ताबड़तोड़ भाषण दे रहे ओवैसी को पता भी नहीं चला और उनकी पीठ के पीछे ऐसा खेल हुआ कि उनकी पांच साल की मेहनत हवा में गायब हो गई। एक तरह से बिहार की राजनीति से ओवैसी का पत्ता एक झटके में साफ हो गया है।',
            category: 'एजुकेशन-जॉब',

        },
        {
            id: '6',
            name: 'ऑटो',
            url: 'https://static.langimg.com/thumb/msid-92537065,imgsize-46828,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'बॉम्बे चौपाटी, ब्रेबोर्न स्टेडियम, मुंबई सेंट्रल रेलवे स्टेशन...आधी मुंबई बसाने के पीछे शापूरजी पालोनजी मिस्त्री',
            discription: '– नई दिल्ली: अरबपति कारोबारी और रियल स्टेट की दुनिया में एक बड़ा नाम शापूरजी पालोनजी समूह के प्रमुख पालोनजी मिस्त्री का निधन हो गया। पालोनजी मिस्त्री की मृत्यू के बाद यादों के रूप में लोगों के सामने वो इमारते हैं जो आज उन्होंने बनवाईं थीं। ये इमारते आज मुंबई की शान हैं और लगभग-लगभग हर इंसान जो भी मुंबई में रहने वाले होंगे वो कभी न कभी यहां पर जरूर गए होंगे। पालोनजी शापूरजी मिस्त्री समूह ने लगभग आधी मुंबई बसाई थी।',
            category: 'ऑटो',

        },
        {
            id: '7',
            name: 'एजुकेशन-जॉब',
            url: 'https://static.langimg.com/thumb/msid-92442939,imgsize-65792,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'इंदिरा गांधी और सिंडिकेट की जंग, कांग्रेस का बंटवारा... कहानी सबसे विवादित राष्ट्रपति चुनाव की',
            discription: '– राष्ट्रपति भवन की रेस औपचारिक रूप से शुरू हो चुकी है। एनडीए ने आदिवासी नेता द्रौपदी मुर्मू को उम्मीदवार बनाकर दांव चल दिया है। विपक्षी दलों के लिए इसकी काट निकाल पाना आसान मालूम नहीं होता। उन्होंने यशवंत सिन्‍हा को उम्मीदवार घोषित किया है। अप्रत्याशित परिणाम की संभावना कम ही है और हुआ भी तो कम से कम 1969 जैसा हाल नहीं होगा। 1969 का राष्ट्रपति चुनाव भारत के इतिहास में सर्वोच्च पद के लिए हुआ सबसे दिलचस्प चुनाव था।',
            category: 'एजुकेशन-जॉब',

        },
        {
            id: '8',
            name: 'ऑटो',
            url: 'https://static.langimg.com/thumb/msid-92521573,imgsize-43460,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'आशिकी 2 हिट होने के बाद मुझे रोमांटिक फिल्में ही मिलने लगीं: आदित्य रॉय कपूर',
            discription: '– अभी तक स्क्रीन पर अपनी आशिकी का फितूर दिखाकर खुद को रोमांटिक हीरो के रूप में स्थापित करने वाले ऐक्टर आदित्य रॉय कपूर अब ऐक्शन अवतार में दर्शकों को चौंकाने वाले हैं। अपनी नई फिल्म राष्ट्र कवच ओम में आदित्य जोरदार ऐक्शन करते दिखेंगे। इसी सिलसिले में हमने उनसे की ये खास बातचीत:',
            category: 'ऑटो',

        },


    ])
    const [currentnews, setCurrentNews] = useState({})

    const [clickedId, setClickedId] = useState('सभी')
    const onPressButton = () => {

    }
    const renderSlider = ({ item }) => {
        return (
            <View
                style={{
                    //height: horizScale(600),
                    height: Dimensions.get('window').height,
                    width: Dimensions.get('window').width,
                    //width: horizScale(450),
                    //justifyContent: 'center',
                    alignItems: 'center',
                    backgroundColor: Customcolor.lightwhite,

                    alignSelf: 'center',
                    elevation: 6
                }}>
                <Text style={styles.heading}>{item.heading}</Text>
                <Image
                    source={{ uri: item.url }}
                    style={{
                        height: horizScale(330), alignSelf: 'center',
                        width: Dimensions.get('window').width,
                        resizeMode: 'contain'
                    }}
                />
                <Text style={styles.title}>{item.discription}</Text>
            </View>
        );
    };

    return (
        <SafeAreaView style={styles.container}>


            <FlatList
                data={category}
                contentContainerStyle={{ paddingHorizontal: horizScale(15), marginVertical: horizScale(20), height: horizScale(40) }}
                ItemSeparatorComponent={() => (<View style={{ width: horizScale(15) }} />)}
                renderItem={({ item }) => (
                    <TouchableOpacity
                        style={{
                            justifyContent: 'center',
                            alignItems: 'center',
                            backgroundColor: clickedId == item ? Customcolor.skyblue : Customcolor.white,
                            paddingVertical: horizScale(5),
                            borderRadius: horizScale(50),
                            paddingHorizontal: horizScale(20)

                        }} onPress={() => {
                            setClickedId(item)
                        }}
                    >
                        <Text style={{
                            color: 'white',
                            fontWeight: 'bold',
                            fontSize: fontSize.reqular,
                            color: item == clickedId ? Customcolor.white : Customcolor.black,
                        }}>{item}
                        </Text>
                    </TouchableOpacity >)
                }

                horizontal={true}
                // showsHorizontalScrollIndicator={false}
                keyExtractor={(item) => item.id}
            >
            </FlatList>


            {/* <FlatList
                data={news}
                // contentContainerStyle={{ paddingVertical: vertScale(20) }}
                ItemSeparatorComponent={() => (<View style={{ height: horizScale(200) }} />)}
                renderItem={({ item }) => {
                }}
                keyExtractor={(item) => item.id}
            /> */}

            <FlatList
                data={news}
                //  renderItem={({item}) => <Geeks name={item.name} />}
                renderItem={renderSlider}
                keyExtractor={item => item.id}
                snapToAlignment="start"
                decelerationRate={'fast'}
                snapToInterval={Dimensions.get('window').height}
            />

        </SafeAreaView >
    )
}

const styles = StyleSheet.create({

    // container: {
    //     flex: 1,
    //     backgroundColor: Customcolor.lightwhite,

    // },
    images: {
        width: '95%',
        height: vertScale(230),
        resizeMode: "cover",
        borderRadius: horizScale(5),
        alignSelf: 'center',
    },
    overlytext: {
        color: Customcolor.black,
        fontSize: fontSize.h6,
        fontWeight: "700",
        marginLeft: 10,
        marginTop: 30
    },
    container: {
        flex: 1,
        backgroundColor: Customcolor.lightwhite,
        alignItems: 'center',
        justifyContent: 'center',
    },
    title: {
        color: Customcolor.black,
        fontSize: 20,
        marginTop: horizScale(15),
        marginHorizontal: horizScale(10)
    },
    heading: {
        color: Customcolor.black,
        fontSize: 20,
        margin: horizScale(20),
        fontWeight: 'bold'
    },

})

export default BhirbhScreentab;