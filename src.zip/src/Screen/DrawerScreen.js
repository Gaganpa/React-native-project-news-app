import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const DrawerScreen = () => {
    return (
        <View>
            <Text>DrawerScreen</Text>
        </View>
    )
}

export default DrawerScreen

const styles = StyleSheet.create({})
