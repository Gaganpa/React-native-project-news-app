import {
    StyleSheet, Text,
    TextInput, View,
    Image,
    FlatList,
    TouchableOpacity,

} from 'react-native'
import React, { useState } from 'react'
import { SearchBar } from 'react-native-screens'
import { horizScale } from '../Utility/Layout'

export default function SearchScreen({ navigation }) {
    const [news, setNews] = useState([
        'Sports',
        'Politice',
        'Cinema',
        'Technology',
        'Education',
        'Books',

    ])
    return (
        <View>
            <TouchableOpacity onPress={() => {
                navigation.goBack()
            }}>
                <Image style={styles.imagearrow}
                    source={require('../../Asset/images/arrowleft.png')}>
                </Image>
            </TouchableOpacity>
            <View style={{
                width: '80%', alignSelf: 'center', flexDirection: 'row',
                alignItems: 'center', borderRadius: 40,
                borderWidth: 1, paddingHorizontal: horizScale(10)

            }}>
                <TextInput style={styles.inputsearch} placeholder='Search Here...'
                    placeholderTextColor={'grey'} autoFocus >
                </TextInput>
                <TouchableOpacity onPress={() => {
                    alert('coming soon')
                }}>
                    <Image resizeMode='center' style={styles.searchbar}
                        source={require('../../Asset/images/search.png')}
                    />
                </TouchableOpacity>

            </View>

        </View>
    )
}

const styles = StyleSheet.create({
    imagearrow: {
        width: 21,
        height: 21,
        margin: 10
    },
    searchbar: {
        width: 20,
        height: 20,
    },
    inputsearch: {
        flex: 0.9,
        color: 'grey'
    }
})