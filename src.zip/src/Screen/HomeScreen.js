import 'react-native-gesture-handler';
import * as React from 'react';
import { Button, View, Text, Image } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import HomeScreentab from '../TabbarNavigation/HomeScreentab';
import BhirbhScreentab from '../TabbarNavigation/BhirbhScreentab';
import MycityScreentab from '../TabbarNavigation/MycityScreentab';
import PhotoScreentab from '../TabbarNavigation/PhotoScreentab';
import VedioScreentab from '../TabbarNavigation/VedioScreentab';
import { horizScale } from '../Utility/Layout';
import { fontSize } from '../Utility/Fontsize';


const Tab = createBottomTabNavigator();

export default function HomeScreen() {
    return (
        <Tab.Navigator screenOptions={{
            tabBarStyle: { height: horizScale(60), marginBottom: horizScale(2), paddingVertical: horizScale(5) },
            headerShown: false
        }}>
            <Tab.Screen name="home" component={HomeScreentab}
                options={{
                    headerShown: false,
                    tabBarLabel: 'होम',
                    tabBarLabelStyle: { fontSize: fontSize.medium },
                    tabBarIcon: (focus) => {
                        return (
                            <Image style={{
                                width: horizScale(25), height: horizScale(25),
                                tintColor: focus.focused ? 'blue' : 'grey'
                            }}
                                source={require('../../Asset/images/Home.png')}
                            />
                        )
                    }
                }}
            />
            <Tab.Screen name="ब्रीफ" component={BhirbhScreentab}
                options={{
                    headerShown: false,
                    tabBarLabel: 'ब्रीफ',
                    tabBarLabelStyle: { fontSize: fontSize.medium },
                    tabBarIcon: (focus) => {
                        return (
                            <Image style={{ width: horizScale(25), height: horizScale(25), tintColor: focus.focused ? 'blue' : 'grey' }}
                                source={require('../../Asset/images/bhriph.png')} />
                        )
                    }
                }}
            />
            <Tab.Screen name="मेरा शहर" component={MycityScreentab}
                options={{
                    headerShown: false,
                    tabBarLabel: 'मेरा शहर',
                    tabBarLabelStyle: { fontSize: fontSize.medium },
                    tabBarIcon: (focus) => {
                        return (
                            <Image style={{ width: horizScale(25), height: horizScale(25), tintColor: focus.focused ? 'blue' : 'grey' }}
                                source={require('../../Asset/images/map1.png')}
                            />
                        )
                    }
                }}
            />
            <Tab.Screen name="फ़ोटो" component={PhotoScreentab}
                options={{
                    headerShown: false,
                    tabBarLabel: 'फ़ोटो',
                    tabBarLabelStyle: { fontSize: fontSize.medium },
                    tabBarIcon: (focus) => {
                        return (
                            <Image style={{ width: horizScale(25), height: horizScale(25), tintColor: focus.focused ? 'blue' : 'grey' }}
                                source={require('../../Asset/images/photo1.png')}
                            />
                        )
                    }
                }}
            />
            <Tab.Screen name="वीडियो" component={VedioScreentab}
                options={{
                    headerShown: false,
                    tabBarLabel: 'वीडियो',
                    tabBarLabelStyle: { fontSize: fontSize.medium },
                    tabBarIcon: (focus) => {
                        return (
                            <Image style={{ width: horizScale(25), height: horizScale(25), tintColor: focus.focused ? 'blue' : 'grey' }}
                                source={require('../../Asset/images/vedio.png')}
                            />
                        )
                    }
                }}
            />
        </Tab.Navigator>

    );
}
