import {
    View, Text,
    StyleSheet,
    Image,
    FlatList,
    ScrollView,
    TouchableOpacity
} from 'react-native'
import React, { useState } from 'react'
import { Customcolor } from '../Utility/Customcolor';
import { Customimage } from '../Utility/Customimage';
import { fontSize } from '../Utility/Fontsize';
import { horizScale, Layout, vertScale } from '../Utility/Layout';

const DetailedScreen = (props) => {
    const { news } = props.route.params
    return (
        <ScrollView>

            <View>
                <View>
                    <TouchableOpacity onPress={() => {
                        props.navigation.goBack()
                    }}>
                        <Image style={{ width: horizScale(20), height: vertScale(20), marginTop: vertScale(15), marginLeft: 10 }}
                            source={require('../../Asset/images/back.png')} />
                        <Text style={styles.backtext}>Back</Text>
                    </TouchableOpacity>
                </View>
                <View>
                    <Text style={styles.topheadline}>{news.heading}</Text>
                    <Image style={styles.imagescover}
                        source={{ uri: news.url }}
                    ></Image>
                    <Text style={styles.subheadline}>{news.discription}</Text>
                </View>

            </View>

        </ScrollView>
    )
};
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Customcolor.lightwhite
    },
    topheadline: {
        color: Customcolor.black,
        fontSize: fontSize.h5,
        fontWeight: '700',
        marginTop: vertScale(20),
        marginLeft: horizScale(15),
    },
    subheadline: {
        color: Customcolor.black,
        fontSize: fontSize.medium,
        marginTop: vertScale(20),
        marginLeft: horizScale(10)
    },
    imagescover: {
        height: vertScale(200),
        width: horizScale(370),
        alignSelf: 'center',
        marginTop: vertScale(20),
        borderRadius: 10
    },
    backtext:
    {
        color: 'black',
        position: 'absolute',
        marginLeft: horizScale(50),
        marginTop: vertScale(14),
        fontWeight: '600',
        fontSize: fontSize.input
    }
})

export default DetailedScreen