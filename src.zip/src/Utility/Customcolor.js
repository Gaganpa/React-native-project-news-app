export const Customcolor = {
    blue: '#6546d7',
    lightblue: '#4267b2',
    black: '#000000',
    darkwhite: '#b6b6b6',
    skyblue: '#51a4ff',
    white: '#ffffff',
    lightwhite: '#f1f1f1',
    orange: '#ED7014'

}