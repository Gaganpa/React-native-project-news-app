export const Customimage = {
    flash: require('../../Asset/images/flash.png'),
    back: require('../../Asset/images/back.png'),
    photo: require('../../Asset/images/photo.png'),
}