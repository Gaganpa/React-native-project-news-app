import React, { useState } from 'react';
import {
    View, Text, FlatList,
    StyleSheet,
    ScrollView,
    SafeAreaView,
    Image,
    ImageBackground,
    TouchableOpacity,
    Button,
} from 'react-native';
import { Customcolor } from '../Utility/Customcolor';
import { Customimage } from '../Utility/Customimage';
import { fontSize } from '../Utility/Fontsize';
import { horizScale, Layout, vertScale } from '../Utility/Layout';


const OtherDrawerScreen = ({ navigation }) => {
    const [selectednews, setselectednews] = useState();

    const [news, setnews] = useState([
        {
            id: '1',
            name: 'टॉप',
            url: 'https://static.langimg.com/thumb/msid-92454414,imgsize-97782,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'राष्ट्रपति पद का नामांकन करने पहुंची द्रौपदी मुर्मू ने यूं ही नहीं पहनी थी सफेद साड़ी, जानिए इसका कारण',
            discription: 'ओडिशा के संथाल आदिवासी समुदाय से आने वालीं द्रौपदी मुर्मू को एनडीए का राष्ट्रपति उम्मीदवार घोषित किया है। हर तरफ उनकी सादगी की चर्चा हो रही है। राजनीति से अलग द्रौपदी मुर्मू की को आदिवासियों के बीच महिलाओं की स्थिति सुधारने के लिए भी जाना जाता है। मुर्मू ने अपना नामांकन दाखिल कर दिया है। ',
            category: 'टॉप',

        },
        {
            id: '2',
            name: 'टॉप',
            url: 'https://newsreach-publishers.s3.ap-south-1.amazonaws.com/asliazadi.com/2022/05/Amit-Shah-Book-1.jpg',
            heading: 'पीएम मोदी की प्रामाणिकता और पारदर्शिता पर विरोधी भी नहीं उठा सकते उंगली : शाह',
            discription: 'नई दिल्ली (ईएमएस)। उपराष्ट्रपति एम वेंकैया नायडू ने प्रधानमंत्री नरेन्द्र मोदी को एक ऐसा नेता बताया जिन्होंने दुनिया को यह दिखा दिया कि सपनों को कैसे साकार किया जा सकता है। उपराष्ट्रपति एम वेंकैया नायडु ने आज, 11 मई को नई दिल्ली में ‘मोदी @20: ड्रीम्स मीट डिलीवरी’ पुस्तक का विमोचन किया। इस अवसर पर विदेश मंत्री एस जयशंकर, कई केंद्रीय मंत्री, सांसद व वरिष्ठ नेता उपस्थित थे।',
            category: 'टॉप',

        },
        {
            id: '3',
            name: 'टॉप',
            url: 'https://static.langimg.com/thumb/msid-92455234,imgsize-18494,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: '10 महीने पहले नदीं में गिर गया था iPhone, मिलने पर किया ऑन तो हुआ कुछ ऐसा',
            discription: ' iPhone खरीदने से पहले हर किसी की मानसिकता अलग होती है। लेकिन सब ये जानते हैं कि iPhone खरीदने के बाद वो खराब कम होता है और काफी मजबूत होता है। कंपनी भी समय के साथ ऐसे ही दावे करती है। Apple हमेशा से ऐसा ही प्रमोशन करती है कि उनका फोन सबसे मजबूत शील्ड से बना हुआ है। अब एक ऐसी ही घटना सामने आई है जो ये साबित करती है कि iPhone सच में काफी मजबूत है।',
            category: 'टॉप',



        },
        {
            id: '4',
            name: 'टॉप',
            url: 'https://static.langimg.com/thumb/msid-92453580,imgsize-23686,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'FASTag Viral Video: क्या वाकई स्मार्टवॉच के जरिए फास्टैग से पैसे चुराए जा सकते हैं? जानिए इस वायरल वीडियो का सच',
            discription: 'इन दिनों सोशल मीडिया पर एक वीडियो वायरल (FASTag Viral Video) हो रहा है। इस वीडियो में दिखाया जा रहा है कि एक बच्चा गाड़ी का शीशा साफ करने के बहाने अपने हाथ में बंधी एक घड़ी से फास्टैग स्कैन कर लेता है। इसके बाद वह बच्चा भाग जाता है। वीडियो बनाने वाले शख्स का दावा है कि इस तरह से फास्टैग से पैसे चुराने का स्कैम चला हुआ है। ',
            category: 'टॉप',



        },


    ])
    const [currentnews, setCurrentNews] = useState({})

    const [clickedId, setClickedId] = useState('Home')
    const onPressButton = () => {

    }
    return (
        <SafeAreaView style={styles.container}>
            <ScrollView>

                <View style={{
                    width: '100%', alignSelf: 'center', flexDirection: 'row',
                    alignItems: 'center', top: vertScale(20),
                }}>
                    <View style={{ flex: 0.5, flexDirection: 'row', }}>
                        <TouchableOpacity onPress={() => {
                            navigation.navigate('home')
                        }} style={styles.Imageline}>
                            <Image style={styles.backimage}
                                source={require('../../Asset/images/back.png')} />
                        </TouchableOpacity>

                        <View style={{ flex: 0.4, }}>
                            <Text style={styles.toptext}>
                                {'अन्य'}</Text>
                        </View>
                    </View>
                    <View style={{ flex: 0.5, flexDirection: 'row' }}>
                        <TouchableOpacity onPress={() => {
                            navigation.navigate('search')
                        }} style={{ flex: 0.2 }}>
                            <Image style={styles.Imagesearch}
                                source={require('../../Asset/images/search.png')}>
                            </Image>
                        </TouchableOpacity>
                    </View>
                </View>


                <FlatList style={{ marginTop: vertScale(40) }}
                    data={news}
                    contentContainerStyle={{ paddingVertical: vertScale(10) }}
                    ItemSeparatorComponent={() => (<View style={{ height: horizScale(25) }} />)}
                    renderItem={({ item }) => {
                        if (clickedId == item.category || clickedId == 'Home')
                            return (
                                <TouchableOpacity onPress={() => {
                                    navigation.navigate('detailed', { news: item })
                                }}
                                    style={styles.newsContainer}
                                >


                                    <View style={{ flex: 0.33 }}>
                                        <View>
                                            <Image style={styles.images}
                                                source={{ uri: item.url }}></Image>
                                        </View>
                                    </View>
                                    <View style={{
                                        flex: 0.67, backgroundColor: Customcolor.white, marginLeft: 10,
                                        borderRadius: 10,
                                    }}>
                                        <Text style={styles.overlytext}>{item.heading}</Text>
                                    </View>
                                </TouchableOpacity>
                            )
                    }}
                    keyExtractor={(item) => item.id}
                />
            </ScrollView>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    toptext: {
        width: horizScale(90),
        height: vertScale(25),
        marginLeft: horizScale(40),
        marginTop: vertScale(2),
        color: 'black',
        fontSize: fontSize.h6,
        fontWeight: '700'
    },
    backimage: {
        width: horizScale(20),
        height: vertScale(20),
        marginLeft: horizScale(20),
        marginTop: vertScale(5)
    },
    newsContainer: {
        flexDirection: 'row',
        backgroundColor: Customcolor.white,
        paddingVertical: horizScale(15),
        marginHorizontal: horizScale(15),
        borderRadius: horizScale(15),
        elevation: 5
    },
    container: {
        flex: 1,
        backgroundColor: Customcolor.lightwhite,

    },
    Imageline: {
        flex: 0.1,
        width: horizScale(20),
        height: vertScale(20),
    },

    Imagesearch: {
        width: horizScale(20),
        height: vertScale(20),
        marginLeft: 115,
        marginTop: 5
    },

    images: {
        width: '90%',
        height: 100,
        resizeMode: "cover",
        borderRadius: horizScale(5),
        alignSelf: 'center'

    },
    overlytext: {
        color: Customcolor.black,
        fontSize: fontSize.medium,
        fontWeight: "700",
    }


})

export default OtherDrawerScreen;