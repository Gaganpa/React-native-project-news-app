import React, { useState } from 'react';
import {
    View, Text, FlatList,
    StyleSheet,
    ScrollView,
    SafeAreaView,
    Image,
    ImageBackground,
    TouchableOpacity,
    Button,
} from 'react-native';
import { Customcolor } from '../Utility/Customcolor';
import { Customimage } from '../Utility/Customimage';
import { fontSize } from '../Utility/Fontsize';
import { horizScale, Layout, vertScale } from '../Utility/Layout';


const MoviceDrawerScreen = ({ navigation }) => {
    const [selectednews, setselectednews] = useState();

    const [news, setnews] = useState([
        {
            id: '1',
            name: 'टॉप',
            url: 'https://static.langimg.com/thumb/msid-92457239,imgsize-80402,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'Thor: Love And Thunder से पहले देख लें ये 7 मार्वल फिल्में, वरना कहानी में उलझ जाएंगे, सब ऊपर से निकल जाएगा',
            discription: 'थॉर: लव एंड थंडर’ जल्द ही सिनेमाघरों में दस्तक देगी। दर्शकों के बीच काफी एक्साइटमेंट है क्योंकि एवेंजर्स: एंडगेम के बाद यह थॉर की पहली फिल्म होगी। थॉर के नए सफर को देखने के लिए फैंस काफी इंतजार कर रहे हैं और जेन फोस्टर भी इस फिल्म के लिए वापसी करेंगे। इसके अलावा, क्रिश्चियन बेल इस फिल्म के साथ अपना एमसीयू डेब्यू करेंगे। लेकिन थॉर: लव एंड थंडर देखने से पहले, आपको फिल्म के कैरेक्टर्स के बारे में और अधिक जानने के लिए पहले इन फिल्मों को देखना चाहिए। इन्हें देखने के बाद आपको थॉर की नई फिल्म काफी हद तक समझ आएगी वरना इसे समझने के लिए आपको काफी स्ट्रगल करना पड़ेगा।',
            category: 'टॉप',

        },
        {
            id: '2',
            name: 'टॉप',
            url: 'https://static.langimg.com/thumb/msid-92457295,imgsize-515506,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'सम्राट पृथ्‍वीराज तो डूब गई, क्‍या कोई हिंदी फिल्म बन पाएगी साउथ में बॉलिवुड की बाहुबली?',
            discription: 'हालांकि बॉलिवुडवाले पहले भी अपनी फिल्मों को डब करके साउथ के राज्यों में रिलीज करते रहे हैं। लेकिन पिछले कुछ अरसे में साउथ फिल्मों जैसे  की बंपर सफलता के बाद अब हिंदी फिल्मों के निर्माता भी अपनी फिल्मों को बड़े पैमाने पर तमिल, तेलुगू, मलयालम और कन्नड़ में रिलीज करके नया मार्केट तलाशना चाहते हैं।',
            category: 'टॉप',

        },
        {
            id: '3',
            name: 'टॉप',
            url: 'https://static.langimg.com/thumb/msid-91574889,imgsize-47496,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'जयेशभाई जोरदार भी बॉक्स ऑफिस पर गिरी धड़ाम, क्यों हो रही बॉलिवुड फिल्में बैक टू बैक फ्लॉप?',
            discription: 'पिछले दिनों जब शाहिद कपूर (Shahid Kapoor) और मृणाल ठाकुर की फिल्म (Jersy) बॉक्स ऑफिस पर सुपर फ्लॉप हो गई, तो फिल्म की लीड ऐक्ट्रेस मृणाल ठाकुर (Mrunal Thakur) ने साफ शब्दों में कहा कि जब तेलुगू ऐक्टर नानी की ओरिजिनल फिल्म  यूट्यूब पर मुफ्त में देखने के लिए उपलब्ध है, ',
            category: 'टॉप',



        },
        {
            id: '4',
            name: 'टॉप',
            url: 'https://static.langimg.com/thumb/msid-91560679,imgsize-74432,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'कैसे फ्लॉप हो गईं साउथ सिनेमा के गुणगान से पहले ये भी जान लीजिए',
            discription: 'कोरोना की दूसरी लहर के बाद पहले तेलुगू सिनेमा की पुष्पा (Pushpa) और आरआरआर (RRR) और फिर कन्नड़ सिनेमा की केजीएफ 2 (KGF 2) ने हिंदी बॉक्स आफिस समेत दुनियाभर में जबर्दस्त कमाई करके सफलता के नए रेकॉर्ड बना दिए। खासकर आरआरआर और केजीएफ 2 ने तो 1000 करोड़ क्लब में एंट्री करके सबको हैरान कर दिया। कोरोना के बाद जहां सिनेमा की कामयाबी को लेकर हर कोई चिंतित था।',
            category: 'टॉप',



        },


    ])
    const [currentnews, setCurrentNews] = useState({})

    const [clickedId, setClickedId] = useState('Home')
    const onPressButton = () => {

    }
    return (
        <SafeAreaView style={styles.container}>
            <ScrollView>

                <View style={{
                    width: '100%', alignSelf: 'center', flexDirection: 'row',
                    alignItems: 'center', top: vertScale(20),
                }}>
                    <View style={{ flex: 0.5, flexDirection: 'row', }}>
                        <TouchableOpacity onPress={() => {
                            navigation.navigate('home')
                        }} style={styles.Imageline}>
                            <Image style={styles.backimage}
                                source={require('../../Asset/images/back.png')} />
                        </TouchableOpacity>

                        <View style={{ flex: 0.4, }}>
                            <Text style={styles.toptext}>
                                {'मूवी'}</Text>
                        </View>
                    </View>
                    <View style={{ flex: 0.5, flexDirection: 'row' }}>
                        <TouchableOpacity onPress={() => {
                            navigation.navigate('search')
                        }} style={{ flex: 0.2 }}>
                            <Image style={styles.Imagesearch}
                                source={require('../../Asset/images/search.png')}>
                            </Image>
                        </TouchableOpacity>
                    </View>
                </View>


                <FlatList style={{ marginTop: vertScale(40) }}
                    data={news}
                    contentContainerStyle={{ paddingVertical: vertScale(10) }}
                    ItemSeparatorComponent={() => (<View style={{ height: horizScale(25) }} />)}
                    renderItem={({ item }) => {
                        if (clickedId == item.category || clickedId == 'Home')
                            return (
                                <TouchableOpacity onPress={() => {
                                    navigation.navigate('detailed', { news: item })
                                }}
                                    style={styles.newsContainer}
                                >


                                    <View style={{ flex: 0.33 }}>
                                        <View>
                                            <Image style={styles.images}
                                                source={{ uri: item.url }}></Image>
                                        </View>
                                    </View>
                                    <View style={{
                                        flex: 0.67, backgroundColor: Customcolor.white, marginLeft: 10,
                                        borderRadius: 10,
                                    }}>
                                        <Text style={styles.overlytext}>{item.heading}</Text>
                                    </View>
                                </TouchableOpacity>
                            )
                    }}
                    keyExtractor={(item) => item.id}
                />
            </ScrollView>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    toptext: {
        width: horizScale(90),
        height: vertScale(25),
        marginLeft: horizScale(40),
        marginTop: vertScale(2),
        color: 'black',
        fontSize: fontSize.h6,
        fontWeight: '700'
    },
    backimage: {
        width: horizScale(20),
        height: vertScale(20),
        marginLeft: horizScale(20),
        marginTop: vertScale(5)
    },
    newsContainer: {
        flexDirection: 'row',
        backgroundColor: Customcolor.white,
        paddingVertical: horizScale(15),
        marginHorizontal: horizScale(15),
        borderRadius: horizScale(15),
        elevation: 5
    },
    container: {
        flex: 1,
        backgroundColor: Customcolor.lightwhite,

    },
    Imageline: {
        flex: 0.1,
        width: horizScale(20),
        height: vertScale(20),
    },

    Imagesearch: {
        width: horizScale(20),
        height: vertScale(20),
        marginLeft: 115,
        marginTop: 5
    },

    images: {
        width: '90%',
        height: 100,
        resizeMode: "cover",
        borderRadius: horizScale(5),
        alignSelf: 'center'

    },
    overlytext: {
        color: Customcolor.black,
        fontSize: fontSize.medium,
        fontWeight: "700",
    }

})

export default MoviceDrawerScreen;