import React, { useState } from 'react';
import {
    View, Text, FlatList,
    StyleSheet,
    ScrollView,
    SafeAreaView,
    Image,
    ImageBackground,
    TouchableOpacity,
    Button,
} from 'react-native';
import { Customcolor } from '../Utility/Customcolor';
import { Customimage } from '../Utility/Customimage';
import { fontSize } from '../Utility/Fontsize';
import { horizScale, Layout, vertScale } from '../Utility/Layout';


const BhirphDrawerScreen = ({ navigation }) => {
    const [selectednews, setselectednews] = useState();

    const [news, setnews] = useState([
        {
            id: '1',
            name: 'टॉप',
            url: 'https://static.langimg.com/thumb/msid-92453154,imgsize-60598,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'वही दिन, वही मैदान.... आज भारत ने सिर्फ पहला विश्व कप नहीं जीता बल्कि रखी थी बादशाहत की नींव',
            discription: '25 जून... भारतीय क्रिकेट इतिहास में यह तारीख बेहद खास है। इसी दिन कपिल देव की कप्तानी में भारत को उसका पहला वर्ल्ड कप (1983 world cup) मिला था। किसी ने सपने में भी नहीं सोचा था कि भारत फाइनल तक पहुंचेगा और लगातार दो बार की चैंपियन वेस्टइंडीज खिताबी जंग हार जाएगी।',
            category: 'टॉप',

        },
        {
            id: '2',
            name: 'टॉप',
            url: 'https://static.langimg.com/thumb/msid-92454765,imgsize-18252,width-400,height-300,resizemode-75/navbharat-times.jpg',
            heading: 'Yogi Adityanath: शकुनियों ने सत्य के खिलाफ लाक्षागृह सजाया, सत्य सकुशल बाहर आया...जानिए योगी ने क्यों कही ये बात',
            discription: 'उत्तर प्रदेश (Uttar Pradesh) के मुख्यमंत्री योगी आदित्यनाथ (Yogi Adityanath) ने गुजरात दंगे (Gujrat Riots) को लेकर आए सुप्रीम कोर्ट के फैसले के बाद विपक्षी दलों पर बड़ा हमला बोला है। 2002 के गुजरात दंगों (2002 Gujrat Riots) को आधार बनाकर लगातार विपक्ष नरेंद्र मोदी (Narendra Modi) को घेरता रहा है। उनके मुख्यमंत्री काल से लेकर प्रधानमंत्री बनने के बाद तक इस मामले को लेकर सवाल उठाए जाते रहे हैं। ',
            category: 'टॉप',

        },
        {
            id: '3',
            name: 'टॉप',
            url: 'https://static.langimg.com/thumb/msid-92453982,imgsize-85092,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'किसान कैसे करें बिजली बिल बकाया भुगतान? UP आसान किस्त योजना से जुड़े इन सवालों के जवाब जानते हैं आप?',
            discription: ' उत्तर प्रदेश सरकार ने पूरे राज्य में आसान किश्त योजना लागू की है। प्रदेश की आबादी में बहुत बड़ा हिस्सा ऐसे लोगों का है जो अपने रोज के जीवन यापन के लिए कमाई पर निर्भर हैं, ऐसे में उनके लिए बिजली का बकाया बिल चुकाना काफी मुश्किल हो जाता है। आसान किस्त योजना के तहत यूपी के किसान अपने बकाया ट्यूबवेल बिजली बिल का भुगतान किश्तों (installments) में कर सकते हैं।',
            category: 'टॉप',



        },
        {
            id: '4',
            name: 'टॉप',
            url: 'https://static.langimg.com/thumb/msid-92453081,imgsize-38328,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: '150 साल पीछे चला जाएगा अमेरिका, गुस्से में बोले बाइडन... गर्भपात पर SC के फैसले से भड़के दिग्गज',
            discription: 'वाशिंगटन: अमेरिका की सुप्रीम कोर्ट ने गर्भपात को कानूनी तौर पर मंजूरी देने वाले एक फैसले को पलट दिया है। इस फैसले के साथ ही अमेरिका में गर्भपात को संवौधानिक संरक्षण समाप्त हो गया है। सुप्रीम कोर्ट के इस फैसले के बाद अमेरिका समेत पूरी दुनिया में बहस छिड़ गई है। अमेरिकी राष्ट्रपति जो बाइडेन (Joe Biden) ने भी इस फैसले पर प्रतिक्रिया दी है। उन्होंने इसे देश के लिए एक दुखद दिन बताया।',
            category: 'टॉप',



        },


    ])
    const [currentnews, setCurrentNews] = useState({})

    const [clickedId, setClickedId] = useState('Home')
    const onPressButton = () => {

    }
    return (
        <SafeAreaView style={styles.container}>
            <ScrollView>

                <View style={{
                    width: '100%', alignSelf: 'center', flexDirection: 'row',
                    alignItems: 'center', top: vertScale(20),
                }}>
                    <View style={{ flex: 0.5, flexDirection: 'row', }}>
                        <TouchableOpacity onPress={() => {
                            navigation.navigate('home')
                        }} style={styles.Imageline}>
                            <Image style={styles.backimage}
                                source={require('../../Asset/images/back.png')} />
                        </TouchableOpacity>

                        <View style={{ flex: 0.4, }}>
                            <Text style={styles.toptext}>
                                {'ब्रीफ'}</Text>
                        </View>
                    </View>
                    <View style={{ flex: 0.5, flexDirection: 'row' }}>
                        <TouchableOpacity onPress={() => {
                            navigation.navigate('search')
                        }} style={{ flex: 0.2 }}>
                            <Image style={styles.Imagesearch}
                                source={require('../../Asset/images/search.png')}>
                            </Image>
                        </TouchableOpacity>
                    </View>
                </View>


                <FlatList style={{ marginTop: 40 }}
                    data={news}
                    contentContainerStyle={{ paddingVertical: vertScale(10) }}
                    ItemSeparatorComponent={() => (<View style={{ height: horizScale(25) }} />)}
                    renderItem={({ item }) => {
                        if (clickedId == item.category || clickedId == 'Home')
                            return (
                                <TouchableOpacity onPress={() => {
                                    navigation.navigate('detailed', { news: item })
                                }}
                                    style={styles.newsContainer}
                                >


                                    <View style={{ flex: 0.33 }}>
                                        <View>
                                            <Image style={styles.images}
                                                source={{ uri: item.url }}></Image>
                                        </View>
                                    </View>
                                    <View style={{
                                        flex: 0.67, backgroundColor: '#fff', marginLeft: 10,
                                        borderRadius: 10,
                                    }}>
                                        <Text style={styles.overlytext}>{item.heading}</Text>
                                    </View>
                                </TouchableOpacity>
                            )
                    }}
                    keyExtractor={(item) => item.id}
                />
            </ScrollView>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    toptext: {
        width: horizScale(50),
        height: vertScale(20),
        marginLeft: horizScale(40),
        marginTop: vertScale(2),
        color: 'black',
        fontSize: fontSize.h6,
        fontWeight: '700'
    },
    backimage: {
        width: horizScale(20),
        height: vertScale(20),
        marginLeft: horizScale(20),
        marginTop: vertScale(5)
    },
    newsContainer: {
        flexDirection: 'row',
        backgroundColor: Customcolor.white,
        paddingVertical: horizScale(15),
        marginHorizontal: horizScale(15),
        borderRadius: horizScale(15),
        elevation: 5
    },
    container: {
        flex: 1,
        backgroundColor: Customcolor.lightwhite,

    },
    Imageline: {
        flex: 0.1,
        width: horizScale(20),
        height: vertScale(20),
    },

    Imagesearch: {
        width: horizScale(20),
        height: vertScale(20),
        marginLeft: 115,
        marginTop: 5
    },

    images: {
        width: '90%',
        height: 100,
        resizeMode: "cover",
        borderRadius: horizScale(5),
        alignSelf: 'center'

    },
    overlytext: {
        color: Customcolor.black,
        fontSize: fontSize.medium,
        fontWeight: "700",
    }

})

export default BhirphDrawerScreen;