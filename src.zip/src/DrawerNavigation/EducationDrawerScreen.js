import React, { useState } from 'react';
import {
    View, Text, FlatList,
    StyleSheet,
    ScrollView,
    SafeAreaView,
    Image,
    ImageBackground,
    TouchableOpacity,
    Button,
} from 'react-native';
import { Customcolor } from '../Utility/Customcolor';
import { Customimage } from '../Utility/Customimage';
import { fontSize } from '../Utility/Fontsize';
import { horizScale, Layout, vertScale } from '../Utility/Layout';


const EducationDrawerScreen = ({ navigation }) => {
    const [selectednews, setselectednews] = useState();

    const [news, setnews] = useState([
        {
            id: '1',
            name: 'टॉप',
            url: 'https://static.langimg.com/thumb/msid-92456314,imgsize-151398,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'HPBOSE 10th Result 2022: सोमवार को आ जाएगा एचपी बोर्ड के 10वीं का रिजल्ट! SMS पर यूं मिलेगा',
            discription: 'हिमाचल प्रदेश बोर्ड ऑफ सेकंडरी एजुकेशन (HPBOSE) सोमवार यानी 27 जून तक हिमाचल बोर्ड के 10वीं के नतीजे (HPBOSE 10th Result 2022) घोषित कर सकता है। जल्द ही बोर्ड की तरफ से नतीजों के तारीख की ऑफिशियल घोषणा कर दी जाएगी। बोर्ड की कक्षा 10 की परीक्षा में उपस्थित छात्र नतीजे जारी होने के बाद ऑफिशियल वेबसाइट hpbose.org पर जाकर अपना परिणाम देख पाएंगे। छात्रों को अपना लॉगिन क्रेडेंशियल दर्ज करना होगा। अन्य बोर्ड की तरह हिमाचल बोर्ड की परीक्षा भी दो टर्म में आयोजित की गई थी। इस बार 10वीं के दोनों टर्म के नतीजे एक साथ फाइनल रिजल्ट के रूप में जारी किए जाएंगे।',
            category: 'टॉप',

        },
        {
            id: '2',
            name: 'टॉप',
            url: 'https://static.langimg.com/thumb/msid-92451924,imgsize-104884,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'PSEB 12th Result 2022: आ गई है बोर्ड के 12वीं के रिजल्ट की तारीख, देखें कब जारी होगा परिणाम',
            discription: 'पंजाब स्कूल एजुकेशन बोर्ड (PSEB) जल्दी ही पंजाब बोर्ड के 12वीं के नतीजे (PSEB 12th Result 2022) घोषित करेगा। जो भी छात्र बोर्ड की परीक्षा में उपस्थित थे वे ऑफिशियल वेबसाइट pseb.ac.in पर जाकर अपना रिजल्ट (Punjab Board Result 2022) चेक कर पाएंगे। सूत्रों के अनुसार पंजाब बोर्ड के ऑफिशियल ने जानकारी दी है कि 30 जून को परिणाम जारी कर सकता है। बोर्ड की तरफ से रिजल्ट तारीखों को लेकर जल्द ही ऑफिशियल घोषणा की जाएगी। छात्रों को सलाह दी जाती है कि वेबसाइट पर नजर बनाकर रखें।',
            category: 'टॉप',

        },
        {
            id: '3',
            name: 'टॉप',
            url: 'https://static.langimg.com/thumb/msid-92454155,imgsize-65052,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'लेखक बनने का सपना, जानें कौन हैं गूगल डूडल वाली एनी फ्रैंक',
            discription: 'आपने 10वीं कक्षा में द डायरी ऑफ अ यंग गर्ल (The Diary Of A Young Girl) नाम की पुस्तक पढ़ी होगी। उस पुस्तक में एक छोटी बच्ची और उसके डायरी का जिक्र था। वो डायरी 15 साल की एक छोटी बच्ची एनी फ्रेंक ने लिखी थी। आज जर्मनी की एनी फ्रैंक की डायरी की 75वीं एनिवर्सरी है और इस मौके पर गूगल ने एक खास डूडल (Goggle Doddle Today) तैयार किया है। आइए जानते हैं कौन हैं डायरी लिखने वाली एनी फ्रैंक और कैसा था उनका जीवन।',
            category: 'टॉप',



        },
        {
            id: '4',
            name: 'टॉप',
            url: 'https://static.langimg.com/thumb/msid-92390894,imgsize-27796,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'ICMAI CMA Admit Card 2022: सीएमए परीक्षा का एडमिट कार्ड ऑफिशियल वेबसाइट icmai.in पर जारी किया गया है।',
            discription: 'इंस्टीट्यूट ऑफ कॉस्ट अकाउंटेंट्स ऑफ इंडिया, ICMAI ने जून टर्म परीक्षा के लिए एडमिट कार्ड (ICMAI CMA Admit Card 2022) जारी कर दिया है। उम्मीदवार जो इंटरमीडिएट और फाइनल जून 2022 टर्म परीक्षा के लिए उपस्थित होंगे, वे ICMAI की ऑफिशियल वेबसाइट icmai.in से एडमिट कार्ड (ICMAI CMA Admit Card) डाउनलोड कर सकते हैं। ICMAI CMA एडमिट कार्ड 2022 जून में होने वाली परीक्षा के लिए उपलब्ध कराया गया है। कार्यक्रम के अनुसार, ICMAI CMA इंटरमीडिएट और फाइनल परीक्षा 27 जून से होगी और 3 जुलाई, 2022 को समाप्त होगी।',
            category: 'टॉप',



        },


    ])
    const [currentnews, setCurrentNews] = useState({})

    const [clickedId, setClickedId] = useState('Home')
    const onPressButton = () => {

    }
    return (
        <SafeAreaView style={styles.container}>
            <ScrollView>

                <View style={{
                    width: '100%', alignSelf: 'center', flexDirection: 'row',
                    alignItems: 'center', top: vertScale(20),
                }}>
                    <View style={{ flex: 0.5, flexDirection: 'row', }}>
                        <TouchableOpacity onPress={() => {
                            navigation.navigate('home')
                        }} style={styles.Imageline}>
                            <Image style={styles.backimage}
                                source={require('../../Asset/images/back.png')} />
                        </TouchableOpacity>

                        <View style={{ flex: 0.4, }}>
                            <Text style={styles.toptext}>
                                {'एजुकेशन'}</Text>
                        </View>
                    </View>
                    <View style={{ flex: 0.5, flexDirection: 'row' }}>
                        <TouchableOpacity onPress={() => {
                            navigation.navigate('search')
                        }} style={{ flex: 0.2 }}>
                            <Image style={styles.Imagesearch}
                                source={require('../../Asset/images/search.png')}>
                            </Image>
                        </TouchableOpacity>
                    </View>
                </View>


                <FlatList style={{ marginTop: vertScale(40) }}
                    data={news}
                    contentContainerStyle={{ paddingVertical: vertScale(10) }}
                    ItemSeparatorComponent={() => (<View style={{ height: horizScale(25) }} />)}
                    renderItem={({ item }) => {
                        if (clickedId == item.category || clickedId == 'Home')
                            return (
                                <TouchableOpacity onPress={() => {
                                    navigation.navigate('detailed', { news: item })
                                }}
                                    style={styles.newsContainer}
                                >


                                    <View style={{ flex: 0.33 }}>
                                        <View>
                                            <Image style={styles.images}
                                                source={{ uri: item.url }}></Image>
                                        </View>
                                    </View>
                                    <View style={{
                                        flex: 0.67, backgroundColor: Customcolor.white, marginLeft: 10,
                                        borderRadius: 10,
                                    }}>
                                        <Text style={styles.overlytext}>{item.heading}</Text>
                                    </View>
                                </TouchableOpacity>
                            )
                    }}
                    keyExtractor={(item) => item.id}
                />
            </ScrollView>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    toptext: {
        width: horizScale(90),
        height: vertScale(25),
        marginLeft: horizScale(40),
        marginTop: vertScale(2),
        color: 'black',
        fontSize: fontSize.h6,
        fontWeight: '700'
    },
    backimage: {
        width: horizScale(20),
        height: vertScale(20),
        marginLeft: horizScale(20),
        marginTop: vertScale(5)
    },
    newsContainer: {
        flexDirection: 'row',
        backgroundColor: Customcolor.white,
        paddingVertical: horizScale(15),
        marginHorizontal: horizScale(15),
        borderRadius: horizScale(15),
        elevation: 5
    },
    container: {
        flex: 1,
        backgroundColor: Customcolor.lightwhite,

    },
    Imageline: {
        flex: 0.1,
        width: horizScale(20),
        height: vertScale(20),
    },

    Imagesearch: {
        width: horizScale(20),
        height: vertScale(20),
        marginLeft: 115,
        marginTop: 5
    },

    images: {
        width: '90%',
        height: 100,
        resizeMode: "cover",
        borderRadius: horizScale(5),
        alignSelf: 'center'

    },
    overlytext: {
        color: Customcolor.black,
        fontSize: fontSize.medium,
        fontWeight: "700",
    }

})

export default EducationDrawerScreen;