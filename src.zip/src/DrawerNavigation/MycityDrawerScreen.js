import React, { useState } from 'react';
import {
    View, Text, FlatList,
    StyleSheet,
    ScrollView,
    SafeAreaView,
    Image,
    ImageBackground,
    TouchableOpacity,
    Button,
} from 'react-native';
import { Customcolor } from '../Utility/Customcolor';
import { Customimage } from '../Utility/Customimage';
import { fontSize } from '../Utility/Fontsize';
import { horizScale, Layout, vertScale } from '../Utility/Layout';


const MycityDrawerScreen = ({ navigation }) => {
    const [selectednews, setselectednews] = useState();

    const [news, setnews] = useState([
        {
            id: '1',
            name: 'टॉप',
            url: 'https://static.langimg.com/thumb/msid-92430527,imgsize-105860,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'गुरुग्राम मौसम: अगले 7 दिन तक नहीं होगी बारिश, तापमान 38 डिग्री तक पहुंचा',
            discription: 'गुड़गांव: अगले 7 दिन तक बारिश नहीं होगी और तापमान का स्तर भी सामान्य रहेगा। गुरुवार को अधिकतम तापमान 38 डिग्री और न्यूनतम तापमान 25 डिग्री सेल्सियस दर्ज किया गया। जो सामान्य से केवल 2.2 डिग्री सेल्सियस ही कम है। पिछले 24 घंटे में बारिश का स्तर शून्य रहा। बीते कुछ दिनों से बीच-बीच में हो रही बारिश की वजह से मौसम सुहाना हो गया था और शहरवासियों को गर्मी से काफी राहत मिली थी और अधिकतम तापमान 11 डिग्री कम होकर 31 डिग्री तक पहुंच गया था।',
            category: 'टॉप',

        },
        {
            id: '2',
            name: 'टॉप',
            url: 'https://static.langimg.com/thumb/msid-92430371,imgsize-74206,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'गुरुग्राम: संक्रमित हैं तो छुपाएं नहीं, आरडब्ल्यूए को सूचना जरूर दें, कोविड के बढ़ते केस देखते हुए जिला प्रशासन ने दिए निर्देश',
            discription: 'गुड़गांव: शहर में इन दिनों कोरोना वायरस संक्रमितों के मामलों में बढ़ोतरी हो रही है। संक्रमण के ज्यादातर मामलों की पुष्टि पॉश इलाकों में हो रही है। जिला प्रशासन की ओर से कहा गया है कि संक्रमित होने पर रेजिडेंशियल सोसाइटी में रहने वाले लोगों को इसकी सूचना आरडब्लूए को जरूर देनी होगी। वहीं संक्रमण के बढ़ते खतरे के बीच मेडिकल स्टोरों से बिक रही होम एंटीजन टेस्ट किट की बेहद कम रिपोर्ट ही स्वास्थ्य विभाग को मिल रही है। इसे संक्रमण के लिहाज से नए खतरे की नजर से देखा जा रहा है। अधिकारियों की मानें तो दो दिन पूर्व आईसीएमआर पोर्टल पर 14 लोगों के होम किट से टेस्ट होने पर संक्रमित होने की जानकारी मिली थी।',
            category: 'टॉप',

        },
        {
            id: '3',
            name: 'टॉप',
            url: 'https://static.langimg.com/thumb/msid-92453982,imgsize-85092,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'किसान कैसे करें बिजली बिल बकाया भुगतान? UP आसान किस्त योजना से जुड़े इन सवालों के जवाब जानते हैं आप?',
            discription: ' उत्तर प्रदेश सरकार ने पूरे राज्य में आसान किश्त योजना लागू की है। प्रदेश की आबादी में बहुत बड़ा हिस्सा ऐसे लोगों का है जो अपने रोज के जीवन यापन के लिए कमाई पर निर्भर हैं, ऐसे में उनके लिए बिजली का बकाया बिल चुकाना काफी मुश्किल हो जाता है। आसान किस्त योजना के तहत यूपी के किसान अपने बकाया ट्यूबवेल बिजली बिल का भुगतान किश्तों (installments) में कर सकते हैं।',
            category: 'टॉप',



        },
        {
            id: '4',
            name: 'टॉप',
            url: 'https://blogs.navbharattimes.indiatimes.com/wp-content/uploads/2022/05/rakhigarhi.jpg',
            heading: 'सोने के जेवर भी पहनते थे हड़प्पा वाले',
            discription: '350 हेक्टेयर में फैले मशहूर राखीगढ़ी पुरास्थल की खुदाई से यह सिद्ध हो गया है कि हड़प्पा सभ्यता का सर्वाधिक सुनियोजित, सुव्यवस्थित, खूबसूरत और बड़ा नगर मोहनजोदड़ो नहीं, बल्कि यही है। फिलहाल जो खुदाई चल रही है, उसमें कब्रें, कंकाल, नगरीय व्यवस्था के साथ-साथ सोने के जेवरों की फैक्ट्री भी मिली है। यह खुदाई इसी महीने बंद होने जा रही है।',
            category: 'टॉप',



        },


    ])
    const [currentnews, setCurrentNews] = useState({})

    const [clickedId, setClickedId] = useState('Home')
    const onPressButton = () => {

    }
    return (
        <SafeAreaView style={styles.container}>
            <ScrollView>

                <View style={{
                    width: '100%', alignSelf: 'center', flexDirection: 'row',
                    alignItems: 'center', top: vertScale(20),
                }}>
                    <View style={{ flex: 0.5, flexDirection: 'row', }}>
                        <TouchableOpacity onPress={() => {
                            navigation.navigate('home')
                        }} style={styles.Imageline}>
                            <Image style={styles.backimage}
                                source={require('../../Asset/images/back.png')} />
                        </TouchableOpacity>

                        <View style={{ flex: 0.4, }}>
                            <Text style={styles.toptext}>
                                {'मेरा शहर'}</Text>
                        </View>
                    </View>
                    <View style={{ flex: 0.5, flexDirection: 'row' }}>
                        <TouchableOpacity onPress={() => {
                            navigation.navigate('search')
                        }} style={{ flex: 0.2 }}>
                            <Image style={styles.Imagesearch}
                                source={require('../../Asset/images/search.png')}>
                            </Image>
                        </TouchableOpacity>
                    </View>
                </View>


                <FlatList style={{ marginTop: 40 }}
                    data={news}
                    contentContainerStyle={{ paddingVertical: vertScale(10) }}
                    ItemSeparatorComponent={() => (<View style={{ height: horizScale(25) }} />)}
                    renderItem={({ item }) => {
                        if (clickedId == item.category || clickedId == 'Home')
                            return (
                                <TouchableOpacity onPress={() => {
                                    navigation.navigate('detailed', { news: item })
                                }}
                                    style={styles.newsContainer}
                                >


                                    <View style={{ flex: 0.33 }}>
                                        <View>
                                            <Image style={styles.images}
                                                source={{ uri: item.url }}></Image>
                                        </View>
                                    </View>
                                    <View style={{
                                        flex: 0.67, backgroundColor: '#fff', marginLeft: 10,
                                        borderRadius: 10,
                                    }}>
                                        <Text style={styles.overlytext}>{item.heading}</Text>
                                    </View>
                                </TouchableOpacity>
                            )
                    }}
                    keyExtractor={(item) => item.id}
                />
            </ScrollView>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    toptext: {
        width: horizScale(90),
        height: vertScale(20),
        marginLeft: horizScale(40),
        marginTop: vertScale(2),
        color: 'black',
        fontSize: fontSize.h6,
        fontWeight: '700'
    },
    backimage: {
        width: horizScale(20),
        height: vertScale(20),
        marginLeft: horizScale(20),
        marginTop: vertScale(5)
    },
    newsContainer: {
        flexDirection: 'row',
        backgroundColor: Customcolor.white,
        paddingVertical: horizScale(15),
        marginHorizontal: horizScale(15),
        borderRadius: horizScale(15),
        elevation: 5
    },
    container: {
        flex: 1,
        backgroundColor: Customcolor.lightwhite,

    },
    Imageline: {
        flex: 0.1,
        width: horizScale(20),
        height: vertScale(20),
    },

    Imagesearch: {
        width: horizScale(20),
        height: vertScale(20),
        marginLeft: 115,
        marginTop: 5
    },

    images: {
        width: '90%',
        height: 100,
        resizeMode: "cover",
        borderRadius: horizScale(5),
        alignSelf: 'center'

    },
    overlytext: {
        color: Customcolor.black,
        fontSize: fontSize.medium,
        fontWeight: "700",
    }

})

export default MycityDrawerScreen;