import React, { useState } from 'react';
import {
    View, Text, FlatList,
    StyleSheet,
    ScrollView,
    SafeAreaView,
    Image,
    ImageBackground,
    TouchableOpacity,
    Button,
} from 'react-native';
import { Customcolor } from '../Utility/Customcolor';
import { Customimage } from '../Utility/Customimage';
import { fontSize } from '../Utility/Fontsize';
import { horizScale, Layout, vertScale } from '../Utility/Layout';


const BusinessDrawerScreen = ({ navigation }) => {
    const [selectednews, setselectednews] = useState();

    const [news, setnews] = useState([
        {
            id: '1',
            name: 'टॉप',
            url: 'https://static.langimg.com/thumb/msid-92457023,imgsize-27026,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'Sri Lanka Foreign Exchange: विदेशी मुद्रा के संकट से जूझते श्रीलंका ने उठाया बड़ा कदम, लोगों के लिए बना दिया एक नया नियम',
            discription: 'कोलंबो: विदेशी मुद्रा के गहरे संकट से जूझ रहे श्रीलंका में एक व्यक्ति के पास रखी जाने वाली विदेशी मुद्रा (Sri Lanka Foreign Exchange) की सीमा घटा दी गई है। अब एक व्यक्ति के पास अधिकतम 10,000 डॉलर की विदेशी मुद्रा ही रह सकती है। श्रीलंका सरकार ने एक आधिकारिक बयान में कहा कि श्रीलंका में रहने वाले या वहां के किसी व्यक्ति द्वारा अपने कब्जे में रखी गई विदेशी मुद्रा की मात्रा को 15,000 अमेरिकी डॉलर से घटाकर 10,000 अमेरिकी डॉलर कर दिया गया है।',
            category: 'टॉप',

        },
        {
            id: '2',
            name: 'टॉप',
            url: 'https://static.langimg.com/thumb/msid-92452269,imgsize-24844,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'NITI Aayog CEO: परमेश्वरन अय्यर बने नीति आयोग के नए सीईओ, जानिए कौन हैं ये और क्या है इनकी खासियत!',
            discription: 'नई दिल्ली: नीति आयोग (Niti Aayog) के नए मुख्य कार्यकारी अधिकारी (CEO) की घोषणा शुक्रवार को कर दी गई है। पूर्व पेयजल और स्वच्छता सचिव परमेश्वरन अय्यर (Parameswaran Iyer) को इस पद पर नियुक्त किया गया है। पिछले साल जुलाई में उन्होंने अपने पद से इस्तीफा दे दिया था। इनकी नियुक्ति अभी दो साल के लिए या अगले आदेश तक के लिए की गई है। नीति आयोग के मौजूदा सीईओ अमिताभ कांत ( Amitabh Kant) 30 जून को रिटायर हो रहे हैं।',
            category: 'टॉप',

        },
        {
            id: '3',
            name: 'टॉप',
            url: 'https://static.langimg.com/thumb/msid-92448972,imgsize-104958,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'Crash Test: अब देश में ही होगा कारों का क्रैश टेस्ट, जानिए ये क्या होता है और कार खरीदते समय कैसे करता है मदद!',
            discription: 'नई दिल्ली: अब देश में गाड़ियों को क्रैश टेस्ट (Crash Test) में उनके प्रदर्शन के आधार पर ‘स्टार रेटिंग’ दी जाएगी। केंद्रीय मंत्री नितिन गडकरी ने कहा कि यह रेटिंग नए प्रोग्राम ‘भारत एनकैप’ के तहत मिलेगी। मसौदे को मंजूरी दे दी गई है। क्रैश टेस्ट में एक से पांच स्टार तक रेटिंग दी जाएगी। इस टेस्ट की गाइडलाइंस को ग्लोबल क्रैश टेस्ट के नियमों से जोड़ा जाएगा। गडकरी ने हाल ही में कहा था कि सरकार का लक्ष्य 2024 तक सड़क दुर्घटना में होने वाली मौत को 50 फीसदी तक कम करना है।',
            category: 'टॉप',



        },
        {
            id: '4',
            name: 'टॉप',
            url: 'https://static.langimg.com/thumb/msid-92443629,imgsize-70174,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'अपने पीक पर दिख रही महंगाई, क्या अब आएगी गिरावट? जानिए क्या कह रहे आरबीआई डिप्टी गवर्नर',
            discription: 'नई दिल्ली : भारतीय रिजर्व बैंक (RBI) के डिप्टी गवर्नर माइकल देबव्रत पात्रा ने शुक्रवार को कहा कि मौद्रिक नीति (Monetary Policy) से जुड़े कदम दुनिया के अन्य देशों के मुकाबले अधिक उदार होंगे, क्योंकि चालू वित्त वर्ष की चौथी तिमाही में मुद्रास्फीति (Inflation) के घटकर छह फीसदी से नीचे आने का अनुमान है। आरबीआई ने बढ़ती खुदरा महंगाई को काबू में लाने के लिये मई और जून में प्रमुख नीतिगत दर रेपो में कुल 0.90 फीसदी की वृद्धि करते हुए 4.9 फीसदी कर दिया है।',
            category: 'टॉप',



        },


    ])
    const [currentnews, setCurrentNews] = useState({})

    const [clickedId, setClickedId] = useState('Home')
    const onPressButton = () => {

    }
    return (
        <SafeAreaView style={styles.container}>
            <ScrollView>

                <View style={{
                    width: '100%', alignSelf: 'center', flexDirection: 'row',
                    alignItems: 'center', top: vertScale(20),
                }}>
                    <View style={{ flex: 0.5, flexDirection: 'row', }}>
                        <TouchableOpacity onPress={() => {
                            navigation.navigate('home')
                        }} style={styles.Imageline}>
                            <Image style={styles.backimage}
                                source={require('../../Asset/images/back.png')} />
                        </TouchableOpacity>

                        <View style={{ flex: 0.4, }}>
                            <Text style={styles.toptext}>
                                {'बिज़नस'}</Text>
                        </View>
                    </View>
                    <View style={{ flex: 0.5, flexDirection: 'row' }}>
                        <TouchableOpacity onPress={() => {
                            navigation.navigate('search')
                        }} style={{ flex: 0.2 }}>
                            <Image style={styles.Imagesearch}
                                source={require('../../Asset/images/search.png')}>
                            </Image>
                        </TouchableOpacity>
                    </View>
                </View>


                <FlatList style={{ marginTop: vertScale(40) }}
                    data={news}
                    contentContainerStyle={{ paddingVertical: vertScale(10) }}
                    ItemSeparatorComponent={() => (<View style={{ height: horizScale(25) }} />)}
                    renderItem={({ item }) => {
                        if (clickedId == item.category || clickedId == 'Home')
                            return (
                                <TouchableOpacity onPress={() => {
                                    navigation.navigate('detailed', { news: item })
                                }}
                                    style={styles.newsContainer}
                                >


                                    <View style={{ flex: 0.33 }}>
                                        <View>
                                            <Image style={styles.images}
                                                source={{ uri: item.url }}></Image>
                                        </View>
                                    </View>
                                    <View style={{
                                        flex: 0.67, backgroundColor: Customcolor.white, marginLeft: 10,
                                        borderRadius: 10,
                                    }}>
                                        <Text style={styles.overlytext}>{item.heading}</Text>
                                    </View>
                                </TouchableOpacity>
                            )
                    }}
                    keyExtractor={(item) => item.id}
                />
            </ScrollView>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    toptext: {
        width: horizScale(90),
        height: vertScale(25),
        marginLeft: horizScale(40),
        marginTop: vertScale(2),
        color: 'black',
        fontSize: fontSize.h6,
        fontWeight: '700'
    },
    backimage: {
        width: horizScale(20),
        height: vertScale(20),
        marginLeft: horizScale(20),
        marginTop: vertScale(5)
    },
    newsContainer: {
        flexDirection: 'row',
        backgroundColor: Customcolor.white,
        paddingVertical: horizScale(15),
        marginHorizontal: horizScale(15),
        borderRadius: horizScale(15),
        elevation: 5
    },
    container: {
        flex: 1,
        backgroundColor: Customcolor.lightwhite,

    },
    Imageline: {
        flex: 0.1,
        width: horizScale(20),
        height: vertScale(20),
    },

    Imagesearch: {
        width: horizScale(20),
        height: vertScale(20),
        marginLeft: 115,
        marginTop: 5
    },

    images: {
        width: '90%',
        height: 100,
        resizeMode: "cover",
        borderRadius: horizScale(5),
        alignSelf: 'center'

    },
    overlytext: {
        color: Customcolor.black,
        fontSize: fontSize.medium,
        fontWeight: "700",
    }

})

export default BusinessDrawerScreen;