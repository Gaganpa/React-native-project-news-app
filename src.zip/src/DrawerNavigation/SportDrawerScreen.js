import React, { useState } from 'react';
import {
    View, Text, FlatList,
    StyleSheet,
    ScrollView,
    SafeAreaView,
    Image,
    ImageBackground,
    TouchableOpacity,
    Button,
} from 'react-native';
import { Customcolor } from '../Utility/Customcolor';
import { Customimage } from '../Utility/Customimage';
import { fontSize } from '../Utility/Fontsize';
import { horizScale, Layout, vertScale } from '../Utility/Layout';


const SportDrawerScreen = ({ navigation }) => {
    const [selectednews, setselectednews] = useState();

    const [news, setnews] = useState([
        {
            id: '1',
            name: 'टॉप',
            url: 'https://static.langimg.com/thumb/msid-92458142,imgsize-41200,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'Roman Walker-Virat Kohli: विराट को आउट करते ही स्टार बना यह अनजान गेंदबाज, बंद नहीं हो रही मोबाइल की घंटी!',
            discription: 'यूं ही नहीं कहते हैं कि विराट कोहली को आउट करने वाला खिलाड़ी रातों रात स्टार बन जाता है। रोमन वॉकर को ही ले लीजिए। लीसेस्टशर के 21 वर्षीय युवा गेंदबाज ने भारत के खिलाफ प्रैक्टिस मैच में विराट कोहली सहित 5 विकेट हासिल किए। इसके बाद तो वह दोस्तों में स्टार बन गए। उनके फोन की घंटी मेसेज और कॉल से घनघनाने लगी। इस बात से वह खुश हैं।',
            category: 'टॉप',

        },
        {
            id: '2',
            name: 'टॉप',
            url: 'https://static.langimg.com/thumb/msid-92458039,imgsize-37406,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'Navdeep Saini: नवदीप सैनी ने प्रैक्टिस मैच में बरपाया कहर, भरत और जडेजा को आउट कर पलट दिया खेल',
            discription: 'इंग्लैंड के खिलाफ पांचवें टेस्ट मैच से पहले भारतीय टीम लीसेस्टरशायर के खिलाफ चार दिनी अभ्यास मैच खेल रही है। इस मुकाबले में लीसेस्टरशायर की टीम ने पहले बल्लेबाजी करते हुए 244 रन का स्कोर खड़ा किया। इसके जवाब में भारतीय टीम ने 8 विकेट पर 246 रन बनाकर अपनी पारी को घोषित किया। वहीं तीसरे दिन के खेल में टीम इंडिया ने लंच ब्रेक तक चार विकेट पर 160 रन बना लिए।',
            category: 'टॉप',

        },
        {
            id: '3',
            name: 'टॉप',
            url: 'https://static.langimg.com/thumb/msid-92457572,imgsize-51646,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'Murali Vijay News: धोनी का चहेता, CSK की शान... 2 वर्ष बाद लौटे मुरली विजय के बल्ले में नहीं दिखी वह जान',
            discription: 'नई दिल्ली: चेन्नई सुपर किंग्स 2010 में आईपीएल का खिताब जीता था। उसके बाद अगले ही साल 2011 में टीम फिर चैंपियन बनी। कई खिलाड़ियों को इस जीत का श्रेय दिया जाता है, लेकिन अगर किसी का नाम नहीं लिया जाता है तो वह मुरली विजय (Murali Vijay) हैं। टीम के लिए 2010 सीजन के शुरुआत में विजय को मध्यक्रम में मौका दिया, लेकिन फिर एमएस धोनी (MS Dhoni) ने उन्हें सलामी बल्लेबाजी के लिए भेजा। इसके बाद से उन्होंने पीछे मुड़कर नहीं देखा। 15 मैच में 458 रन के साथ वह 2010 सीजन में छठे सबसे ज्यादा रन बनाने वाले बल्लेबाज थे। उनका स्ट्राइक रेट था 156.84 का। टॉप-10 बल्लेबाजों में सबसे ज्यादा। 2011 के फाइनल में उनके बल्ले से 95 रन निकले थे।',
            category: 'टॉप',



        },
        {
            id: '4',
            name: 'टॉप',
            url: 'https://static.langimg.com/thumb/msid-92456833,imgsize-74944,width-700,height-525,resizemode-75/navbharat-times.jpg',
            heading: 'Wasim Akram News: जब शेन वॉर्न-ग्लेन मैक्ग्रा दे रहे थे गालियां, पाकिस्तानी को समझ ही नहीं आई.. वसीम अकरम का खुलासा',
            discription: 'पाकिस्तान के पूर्व तेज गेंदबाज वसीम अकरम ने 1996-97 की त्रिकोणीय सीरीज के दौरान ऑस्ट्रेलिया के खिलाफ एक मैच का मजेदार स्लेजिंग किस्सा साझा किया है। अकरम उस समय पाकिस्तान का नेतृत्व कर रहे थे और महान तेज गेंदबाज ने याद किया कि कैसे ऑस्ट्रेलियाई खिलाड़ी शेन वॉर्न और ग्लेन मैकग्रा ने पाकिस्तान के एक बल्लेबाज को गाली दे देकर भी दिया था, लेकिन उन्हें इस बात पता नहीं था कि उनकी ऑस्ट्रेलियाई अंदाज में बोली गई इंग्लिश पाकिस्तानी बल्लेबाज को समझ ही नहीं आ रही थी।',
            category: 'टॉप',



        },


    ])
    const [currentnews, setCurrentNews] = useState({})

    const [clickedId, setClickedId] = useState('Home')
    const onPressButton = () => {

    }
    return (
        <SafeAreaView style={styles.container}>
            <ScrollView>

                <View style={{
                    width: '100%', alignSelf: 'center', flexDirection: 'row',
                    alignItems: 'center', top: vertScale(20),
                }}>
                    <View style={{ flex: 0.5, flexDirection: 'row', }}>
                        <TouchableOpacity onPress={() => {
                            navigation.navigate('home')
                        }} style={styles.Imageline}>
                            <Image style={styles.backimage}
                                source={require('../../Asset/images/back.png')} />
                        </TouchableOpacity>

                        <View style={{ flex: 0.4, }}>
                            <Text style={styles.toptext}>
                                {'खेल'}</Text>
                        </View>
                    </View>
                    <View style={{ flex: 0.5, flexDirection: 'row' }}>
                        <TouchableOpacity onPress={() => {
                            navigation.navigate('search')
                        }} style={{ flex: 0.2 }}>
                            <Image style={styles.Imagesearch}
                                source={require('../../Asset/images/search.png')}>
                            </Image>
                        </TouchableOpacity>
                    </View>
                </View>


                <FlatList style={{ marginTop: vertScale(40) }}
                    data={news}
                    contentContainerStyle={{ paddingVertical: vertScale(10) }}
                    ItemSeparatorComponent={() => (<View style={{ height: horizScale(25) }} />)}
                    renderItem={({ item }) => {
                        if (clickedId == item.category || clickedId == 'Home')
                            return (
                                <TouchableOpacity onPress={() => {
                                    navigation.navigate('detailed', { news: item })
                                }}
                                    style={styles.newsContainer}
                                >


                                    <View style={{ flex: 0.33 }}>
                                        <View>
                                            <Image style={styles.images}
                                                source={{ uri: item.url }}></Image>
                                        </View>
                                    </View>
                                    <View style={{
                                        flex: 0.67, backgroundColor: Customcolor.white, marginLeft: 10,
                                        borderRadius: 10,
                                    }}>
                                        <Text style={styles.overlytext}>{item.heading}</Text>
                                    </View>
                                </TouchableOpacity>
                            )
                    }}
                    keyExtractor={(item) => item.id}
                />
            </ScrollView>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    toptext: {
        width: horizScale(90),
        height: vertScale(25),
        marginLeft: horizScale(40),
        marginTop: vertScale(2),
        color: 'black',
        fontSize: fontSize.h6,
        fontWeight: '700'
    },
    backimage: {
        width: horizScale(20),
        height: vertScale(20),
        marginLeft: horizScale(20),
        marginTop: vertScale(5)
    },
    newsContainer: {
        flexDirection: 'row',
        backgroundColor: Customcolor.white,
        paddingVertical: horizScale(15),
        marginHorizontal: horizScale(15),
        borderRadius: horizScale(15),
        elevation: 5
    },
    container: {
        flex: 1,
        backgroundColor: Customcolor.lightwhite,

    },
    Imageline: {
        flex: 0.1,
        width: horizScale(20),
        height: vertScale(20),
    },

    Imagesearch: {
        width: horizScale(20),
        height: vertScale(20),
        marginLeft: 115,
        marginTop: 5
    },

    images: {
        width: '90%',
        height: 100,
        resizeMode: "cover",
        borderRadius: horizScale(5),
        alignSelf: 'center'

    },
    overlytext: {
        color: Customcolor.black,
        fontSize: fontSize.medium,
        fontWeight: "700",
    }

})

export default SportDrawerScreen;