import React, { useState } from 'react';
import {
    View, Text, FlatList,
    StyleSheet,
    ScrollView,
    SafeAreaView,
    Image,
    ImageBackground,
    TouchableOpacity,
    Button,
} from 'react-native';
import { Customcolor } from '../Utility/Customcolor';
import { Customimage } from '../Utility/Customimage';
import { fontSize } from '../Utility/Fontsize';
import { horizScale, Layout, vertScale } from '../Utility/Layout';


const WebstoryDrawerScreen = ({ navigation }) => {
    const [selectednews, setselectednews] = useState();

    const [news, setnews] = useState([
        {
            id: '1',
            name: 'टॉप',
            url: 'https://static.langimg.com/thumb/msid-92425404,width-680,resizemode-3/navbharat-times.jpg',
            heading: '4 दिन काम और 3 दिन वीकऑफ, ऊपर से मिलेगा ओवरटाइम भी',
            discription: 'नए लेबर कोड लागू होने के बाद काम के अधिकतम घंटे 12 करने का प्रस्ताव है। हालांकि, साप्ताहिक सीमा को 48 घंटे पर फिक्स रखा जाएगा। यानी नई व्यवस्था में 4 दिन काम करके 3 दिन वीकऑफ भी मिल सकेगा, अगर आप रोज 12 घंटे काम करते हैं। वहीं ओवरटाइम के घंटों को भी एक तिमाही में 50 घंटे से बढ़ाकर 125 घंटे कर दिया गया है। इससे वीकेंड पर कर्मचारी ओवरटाइम कर के अतिरिक्त पैसे कमा सकते हैं।',
            category: 'टॉप',

        },
        {
            id: '2',
            name: 'टॉप',
            url: 'https://static.langimg.com/thumb/msid-92425410,width-680,resizemode-3/navbharat-times.jpg',
            heading: 'दोधारी तलवार है 12 घंटे काम और ओवरटाइम की व्यवस्था',
            discription: 'नई व्यवस्था में सिर्फ 4 दिन काम और तीन दिन छुट्टी... ये सुनने में तो बहुत अच्छा लगता है, लेकिन हकीकत थोड़ी अलग है। जिन 4 दिन आप काम करेंगे, वह 12-12 घंटे काम होगा। देर तक काम करने का असर आपके स्वास्थ्य पर दिख सकता है। वहीं कई बार इसके बाद कंपनियां ओवरटाइम के लिए कह सकती हैं। ऐसे में भले ही आपको पैसे थोड़े अधिक मिल जाएंगे, लेकिन आपका काम बहुत अधिक बढ़ जाएगा। देखा जाए तो इससे आपकी सेहत बिगड़ सकती है।',
            category: 'टॉप',

        },
        {
            id: '3',
            name: 'टॉप',
            url: 'https://static.langimg.com/thumb/msid-92425408,width-680,resizemode-3/navbharat-times.jpg',
            heading: 'सिर्फ 180 दिन में ही मिलने लगेगी छुट्टी',
            discription: ' नए लेबर कोड में छुट्टियों को लेकर भी एक बड़ा बदलाव किया गया है। अभी तक किसी नए कर्मचारी को छुट्टियों के लिए योग्य होने के लिए कम से कम 240 दिन काम करना होता था, लेकिन अब कोई भी कर्मचारी सिर्फ 180 दिनों में ही छुट्टी लेने के लिए योग्य हो जाएगा। यानी अब छुट्टी पाने की योग्यता की सीमा तक पहुंचने के लिए आपको कम दिन काम करना होगा। सरकार का यह कदम कर्मचारियों को बड़ी राहत देने वाला है।',
            category: 'टॉप',



        },
        {
            id: '4',
            name: 'टॉप',
            url: 'https://static.langimg.com/thumb/msid-92425401,width-680,resizemode-3/navbharat-times.jpg',
            heading: 'कितनी छुट्टियां मिलेंगी, कितनी होंगी कैरी फॉर्वर्ड',
            discription: 'सरकार ने नई व्यवस्था में छुट्टियों की संख्या को पहले जैसा ही रखा है। यानी हर 20 दिन काम करने पर आपको 1 दिन की छुट्टी मिलेगी। साथ ही, कैरी फॉरवर्ड होने वाली छुट्टियों की संख्या को भी ना बदलते हुए उसकी संख्या 30 रखी गई है। हालांकि, छुट्टियों को लेकर जो प्रावधान सिर्फ मैन्युफैक्चरिंग इंडस्ट्री पर लागू होते थे, अब सभी सेक्टर पर लागू होंगे। इस कदम को खूब तारीफें मिल रही हैं।',
            category: 'टॉप',



        },


    ])
    const [currentnews, setCurrentNews] = useState({})

    const [clickedId, setClickedId] = useState('Home')
    const onPressButton = () => {

    }
    return (
        <SafeAreaView style={styles.container}>
            <ScrollView>

                <View style={{
                    width: '100%', alignSelf: 'center', flexDirection: 'row',
                    alignItems: 'center', top: vertScale(20),
                }}>
                    <View style={{ flex: 0.5, flexDirection: 'row', }}>
                        <TouchableOpacity onPress={() => {
                            navigation.navigate('home')
                        }} style={styles.Imageline}>
                            <Image style={styles.backimage}
                                source={require('../../Asset/images/back.png')} />
                        </TouchableOpacity>

                        <View style={{ flex: 0.4, }}>
                            <Text style={styles.toptext}>
                                {'वेब स्टोरी'}</Text>
                        </View>
                    </View>
                    <View style={{ flex: 0.5, flexDirection: 'row' }}>
                        <TouchableOpacity onPress={() => {
                            navigation.navigate('search')
                        }} style={{ flex: 0.2 }}>
                            <Image style={styles.Imagesearch}
                                source={require('../../Asset/images/search.png')}>
                            </Image>
                        </TouchableOpacity>
                    </View>
                </View>


                <FlatList style={{ marginTop: 40 }}
                    data={news}
                    contentContainerStyle={{ paddingVertical: vertScale(10) }}
                    ItemSeparatorComponent={() => (<View style={{ height: horizScale(25) }} />)}
                    renderItem={({ item }) => {
                        if (clickedId == item.category || clickedId == 'Home')
                            return (
                                <TouchableOpacity onPress={() => {
                                    navigation.navigate('detailed', { news: item })
                                }}
                                    style={styles.newsContainer}
                                >


                                    <View style={{ flex: 0.33 }}>
                                        <View>
                                            <Image style={styles.images}
                                                source={{ uri: item.url }}></Image>
                                        </View>
                                    </View>
                                    <View style={{
                                        flex: 0.67, backgroundColor: '#fff', marginLeft: 10,
                                        borderRadius: 10,
                                    }}>
                                        <Text style={styles.overlytext}>{item.heading}</Text>
                                    </View>
                                </TouchableOpacity>
                            )
                    }}
                    keyExtractor={(item) => item.id}
                />
            </ScrollView>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    toptext: {
        width: horizScale(90),
        height: vertScale(20),
        marginLeft: horizScale(40),
        marginTop: vertScale(2),
        color: 'black',
        fontSize: fontSize.h6,
        fontWeight: '700'
    },
    backimage: {
        width: horizScale(20),
        height: vertScale(20),
        marginLeft: horizScale(20),
        marginTop: vertScale(5)
    },
    newsContainer: {
        flexDirection: 'row',
        backgroundColor: Customcolor.white,
        paddingVertical: horizScale(15),
        marginHorizontal: horizScale(15),
        borderRadius: horizScale(15),
        elevation: 5
    },
    container: {
        flex: 1,
        backgroundColor: Customcolor.lightwhite,

    },
    Imageline: {
        flex: 0.1,
        width: horizScale(20),
        height: vertScale(20),
    },

    Imagesearch: {
        width: horizScale(20),
        height: vertScale(20),
        marginLeft: 115,
        marginTop: 5
    },

    images: {
        width: '90%',
        height: 100,
        resizeMode: "cover",
        borderRadius: horizScale(5),
        alignSelf: 'center'

    },
    overlytext: {
        color: Customcolor.black,
        fontSize: fontSize.medium,
        fontWeight: "700",
    }

})

export default WebstoryDrawerScreen;