import React, { useState } from 'react';
import {
    View, Text, FlatList,
    StyleSheet,
    ScrollView,
    SafeAreaView,
    Image,
    ImageBackground,
    TouchableOpacity,
    Button,
} from 'react-native';
import { Customcolor } from '../Utility/Customcolor';
import { Customimage } from '../Utility/Customimage';
import { fontSize } from '../Utility/Fontsize';
import { horizScale, Layout, vertScale } from '../Utility/Layout';


const PhotoDrawerScreen = ({ navigation }) => {
    const [selectednews, setselectednews] = useState();

    const [news, setnews] = useState([
        {
            id: '1',
            name: 'टॉप',
            url: 'https://static.langimg.com/thumb/msid-92431556,width-680,resizemode-3/navbharat-times.jpg',
            heading: 'FD Rates: रेपो रेट बढ़ने के बाद इन 10 बैंकों ने बढ़ाया एफडी पर ब्याज, जानिए कहां पैसा लगाने से मिलेगा सबसे ज्यादा रिटर्न',
            discription: 'FD Rates: इस महीने के पहले हफ्ते में ही भारतीय रिजर्व बैंक ने रेपो रेट में 50 बेसिस प्वाइंट की बढ़ोतरी की थी। इससे करीब एक महीने पहले भी आरबीआई ने 40 बेसिस प्वाइंट बढ़ाए थे।',
            category: 'टॉप',

        },
        {
            id: '2',
            name: 'टॉप',
            url: 'https://static.langimg.com/thumb/msid-92411202,width-680,resizemode-3/navbharat-times.jpg',
            heading: 'जनकपुर धाम पहुंची पहली श्री रामायण यात्रा ट्रेन, तस्वीरों में देखें ननिहाल में किस तरह हुआ राम भक्तों का भव्य स्वागत',
            discription: 'श्री राम और माता सीता के भक्तों का श्री रामायण यात्रा ट्रेन से यात्रा करने का इंतजार खत्म हो गया है। देश की पहली श्री रामायण यात्रा ट्रेन (Shri Ramayana Yatra Train) 21 जून ',
            category: 'टॉप',

        },
        {
            id: '3',
            name: 'टॉप',
            url: 'https://static.langimg.com/thumb/msid-92385882,width-680,resizemode-3/navbharat-times.jpg',
            heading: 'Akasa Air First Aircraft: भारत पहुंचा झुनझुनवाला की कंपनी आकासा एयर का पहला विमान, दिल खुश कर देंगी तस्वीरें',
            discription: ' Akasa Air First Aircraft: दिग्गज निवेशक राकेश झुनझुनवाला की कंपनी आकासा एयर का पहला बोईंग 737 मैक्स विमान मंगलवार को नई दिल्ली पहुंच गया। इसके साथ ही कंपनी परिचालन शुरू करने के लिए जरूरी एयर परिचालन परमिट हासिल करने के करीब पहुंच गई है।',
            category: 'टॉप',



        },
        {
            id: '4',
            name: 'टॉप',
            url: 'https://static.langimg.com/thumb/msid-92352947,width-680,resizemode-3/navbharat-times.jpg',
            heading: 'Car Loan Interest Rate: EMI पर खरीदना चाहते हैं कार तो पहले जान लीजिए कौन सा बैंक ले रहा है कितना ब्याज, ये रही पूरी लिस्ट',
            discription: 'Car Loan Interest Rate: अगर आप भी कार लोन लेकर नई गाड़ी खरीदने की सोच रहे हैं तो पहले आपको ये पता होना जरूरी है कि लोन किस दर पर मिल रहा है। ईएमआई पर कार खरीदना सहूलियत भरा तो होता है, लेकिन इससे आपकी जेब पर पड़ने वाला बोझ बढ़ जाता है। मान लेते हैं कि आप 5 साल के लिए कार लोन ले रहे हैं। आइए जानते हैं कौन सा बैंक किस दर पर दे रहा है कार लोन।',
            category: 'टॉप',



        },


    ])
    const [currentnews, setCurrentNews] = useState({})

    const [clickedId, setClickedId] = useState('Home')
    const onPressButton = () => {

    }
    return (
        <SafeAreaView style={styles.container}>
            <ScrollView>

                <View style={{
                    width: '100%', alignSelf: 'center', flexDirection: 'row',
                    alignItems: 'center', top: vertScale(20),
                }}>
                    <View style={{ flex: 0.5, flexDirection: 'row', }}>
                        <TouchableOpacity onPress={() => {
                            navigation.navigate('home')
                        }} style={styles.Imageline}>
                            <Image style={styles.backimage}
                                source={require('../../Asset/images/back.png')} />
                        </TouchableOpacity>

                        <View style={{ flex: 0.4, }}>
                            <Text style={styles.toptext}>
                                {'फ़ोटो'}</Text>
                        </View>
                    </View>
                    <View style={{ flex: 0.5, flexDirection: 'row' }}>
                        <TouchableOpacity onPress={() => {
                            navigation.navigate('search')
                        }} style={{ flex: 0.2 }}>
                            <Image style={styles.Imagesearch}
                                source={require('../../Asset/images/search.png')}>
                            </Image>
                        </TouchableOpacity>
                    </View>
                </View>


                <FlatList style={{ marginTop: 40 }}
                    data={news}
                    contentContainerStyle={{ paddingVertical: vertScale(10) }}
                    ItemSeparatorComponent={() => (<View style={{ height: horizScale(25) }} />)}
                    renderItem={({ item }) => {
                        if (clickedId == item.category || clickedId == 'Home')
                            return (
                                <TouchableOpacity onPress={() => {
                                    navigation.navigate('detailed', { news: item })
                                }}
                                    style={styles.newsContainer}
                                >


                                    <View style={{ flex: 0.33 }}>
                                        <View>
                                            <Image style={styles.images}
                                                source={{ uri: item.url }}></Image>
                                        </View>
                                    </View>
                                    <View style={{
                                        flex: 0.67, backgroundColor: '#fff', marginLeft: 10,
                                        borderRadius: 10,
                                    }}>
                                        <Text style={styles.overlytext}>{item.heading}</Text>
                                    </View>
                                </TouchableOpacity>
                            )
                    }}
                    keyExtractor={(item) => item.id}
                />
            </ScrollView>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    toptext: {
        width: horizScale(90),
        height: vertScale(20),
        marginLeft: horizScale(40),
        marginTop: vertScale(2),
        color: 'black',
        fontSize: fontSize.h6,
        fontWeight: '700'
    },
    backimage: {
        width: horizScale(20),
        height: vertScale(20),
        marginLeft: horizScale(20),
        marginTop: vertScale(5)
    },
    newsContainer: {
        flexDirection: 'row',
        backgroundColor: Customcolor.white,
        paddingVertical: horizScale(15),
        marginHorizontal: horizScale(15),
        borderRadius: horizScale(15),
        elevation: 5
    },
    container: {
        flex: 1,
        backgroundColor: Customcolor.lightwhite,

    },
    Imageline: {
        flex: 0.1,
        width: horizScale(20),
        height: vertScale(20),
    },

    Imagesearch: {
        width: horizScale(20),
        height: vertScale(20),
        marginLeft: 115,
        marginTop: 5
    },

    images: {
        width: '90%',
        height: 100,
        resizeMode: "cover",
        borderRadius: horizScale(5),
        alignSelf: 'center'

    },
    overlytext: {
        color: Customcolor.black,
        fontSize: fontSize.medium,
        fontWeight: "700",
    }

})

export default PhotoDrawerScreen;