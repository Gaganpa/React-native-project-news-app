import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import First from '../Auth/First';
import SignupScreen from '../Auth/SignupScreen';
import LoginScreen from '../Auth/LoginScreen';
import Resetpass from '../Auth/Resetpass';
import OtpScreen from '../Auth/OtpScreen';
import SearchScreen from '../Screen/SearchScreen';



const Stack = createNativeStackNavigator();

const Auth = () => {
    return (
        <Stack.Navigator initialRouteName='first' screenOptions={{ headerShown: false }}>
            <Stack.Screen name="first" component={First} options={{ headerShown: false }} />
            <Stack.Screen name="login" component={LoginScreen} />
            <Stack.Screen name="signup" component={SignupScreen} />
            <Stack.Screen name='resetpass' component={Resetpass} />
            <Stack.Screen name='otp' component={OtpScreen} />
        </Stack.Navigator>
    );
};
export default Auth;