import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import HomeScreen from '../Screen/HomeScreen';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { View, Text } from 'react-native-animatable';
import TopDrawerScreen from '../DrawerNavigation/TopDrawerScreen';
import BhirphDrawerScreen from '../DrawerNavigation/BhirphDrawerScreen';
import MycityDrawerScreen from '../DrawerNavigation/MycityDrawerScreen';
import WebstoryDrawerScreen from '../DrawerNavigation/WebstoryDrawerScreen';
import PhotoDrawerScreen from '../DrawerNavigation/PhotoDrawerScreen';
import VedioDrawerScreen from '../DrawerNavigation/VedioDrawerScreen';
import GoldDrawerScreen from '../DrawerNavigation/GoldDrawerScreen';
import BhartDrawerScreen from '../DrawerNavigation/BhartDrawerScreen';
import StateDrawerScreen from '../DrawerNavigation/StateDrawerScreen';
import MetroDrawerScreen from '../DrawerNavigation/MetroDrawerScreen';
import ViralDrawerScreen from '../DrawerNavigation/ViralDrawerScreen';
import MoviceDrawerScreen from '../DrawerNavigation/MoviceDrawerScreen';
import BusinessDrawerScreen from '../DrawerNavigation/BusinessDrawerScreen';
import SportDrawerScreen from '../DrawerNavigation/SportDrawerScreen';
import EducationDrawerScreen from '../DrawerNavigation/EducationDrawerScreen';
import OtherDrawerScreen from '../DrawerNavigation/OtherDrawerScreen';

const Drawer = createDrawerNavigator();
const HomeDrawer = ({ navigation }) => {
    return (
        <Drawer.Navigator initialRouteName="Home" screenOptions={{ headerShown: false }}>
            <Drawer.Screen name="Home" component={HomeScreen} />
            <Drawer.Screen name='टॉप' component={TopDrawerScreen} />
            <Drawer.Screen name='ब्रीफ' component={BhirphDrawerScreen} />
            <Drawer.Screen name='मेरा शहर' component={MycityDrawerScreen} />
            <Drawer.Screen name='वेब स्टोरी' component={WebstoryDrawerScreen} />
            <Drawer.Screen name='फ़ोटो' component={PhotoDrawerScreen} />
            <Drawer.Screen name='वीडियो' component={VedioDrawerScreen} />
            <Drawer.Screen name='GOLD' component={GoldDrawerScreen} />
            <Drawer.Screen name='भारत' component={BhartDrawerScreen} />
            <Drawer.Screen name='राज्य' component={StateDrawerScreen} />
            <Drawer.Screen name='मेट्रो' component={MetroDrawerScreen} />
            <Drawer.Screen name='गुड न्यूज' component={GoldDrawerScreen} />
            <Drawer.Screen name='Viral' component={ViralDrawerScreen} />
            <Drawer.Screen name='मूवी' component={MoviceDrawerScreen} />
            <Drawer.Screen name='बिज़नस' component={BusinessDrawerScreen} />
            <Drawer.Screen name='खेल' component={SportDrawerScreen} />
            <Drawer.Screen name='एजुकेशन' component={EducationDrawerScreen} />
            <Drawer.Screen name='अन्य' component={OtherDrawerScreen} />
        </Drawer.Navigator>


    );
};
export default HomeDrawer;